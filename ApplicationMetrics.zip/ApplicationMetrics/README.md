The documentation in this group is written in  [markdown](https://www.markdownguide.org/basic-syntax/) and built using [
mkdocs-material](https://github.com/squidfunk/mkdocs-material). To preview the output, follow these steps:


1) Download the squidfunk docker image: ```docker pull squidfunk/mkdocs-material:latest```
2) Run the image: ```docker run --rm -it -u 65534 -p 8000:8000 -v ${PWD}:/docs squidfunk/mkdocs-material```
3) Open your browser and go to http://localhost:8000


## Image history 

View the image history using the following command: ```docker history squidfunk/mkdocs-material```

## Image for vulnerabilities

You can scan the image for vulnerabilities using one of these tools:

* [docker scan](https://docs.docker.com/engine/scan/)
* [Coguard-cli](https://github.com/coguardio/coguard-cli)
* [Trivy](https://aquasecurity.github.io/trivy)
* [Grype](https://github.com/anchore/grype)
* [Snyk](https://snyk.io/)
* [Others](https://www.devopsschool.com/blog/top-container-vulnerability-scanning-tools/)

Using the build in docker scan:

```docker scan squidfunk/mkdocs-material```

Using Trivy to scan image from ```Powershell```

```docker run --rm -v /var/run/docker.sock:/var/run/docker.sock -v $HOME/Library/Caches:/root/.cache/ aquasec/trivy:latest image squidfunk/mkdocs-material```

For more information on securing your Docker containers, check out [this article.](https://www.prplbx.com/resources/blog/docker-part1/).

## Usage
Documentation was initialized with the following command:

 ```docker run --rm -it -u 65534 -v ${PWD}:/docs squidfunk/mkdocs-material new .```

View documentation as mkdocs locally use this command: 

```docker run --rm -it -u 65534 -p 8000:8000 -v ${PWD}:/docs squidfunk/mkdocs-material```

Build documentation in strict mode (like the pipeline):

```docker run --rm -it -u 65534 -v ${PWD}:/docs squidfunk/mkdocs-material build --strict```

The user *65534* aka *"nobody"* is a low-privilege Linux user account that is often used to run system services or to limit the permissions of processes running on a system. Running a Docker container as the "nobody" user is a security best practice as it helps to reduce the attack surface of the container by running it with the minimum required privileges. This makes it harder for an attacker to escalate their privileges or access sensitive information on the host system if a vulnerability is discovered in the container.