package dto;

public record MovieQuoteDTO (String quote) {}
