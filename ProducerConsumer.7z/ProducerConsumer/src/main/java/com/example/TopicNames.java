package com.example;


public enum TopicNames {
    SOURCE_TOPIC("source"),
    SINK_TOPIC("sink"),
    MOVIE_QUOTE_SINK_TOPIC("movie_quote_sink"),
    MOVIE_QUOTE_PROTOBUF_SINK_TOPIC("movie_quote_protobuf_sink");

    public final String name;

    TopicNames(String name) {
        this.name = name;
    }
}

