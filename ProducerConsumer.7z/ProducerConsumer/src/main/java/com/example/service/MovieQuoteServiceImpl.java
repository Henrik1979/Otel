package com.example.service;

import com.example.TopicNames;
import dto.MovieQuoteDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class MovieQuoteServiceImpl implements MovieQuoteService {

    private final KafkaTemplate<String, String> kafkaProducer;

    public MovieQuoteServiceImpl(@Autowired KafkaTemplate<String, String> kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    @Override
    public String createMovieQuote(MovieQuoteDTO movieQuote) {

        var id = UUID.randomUUID().toString();

        // await result to make sure the message was delivered, this will be slower than doing it async
        // but here we know if everything went well
        SendResult<String, String> result = null;

        try {
            log.atInfo().setMessage("Sending ProducerRecord").addKeyValue("id", id).log();

            // timeout controlled by kafka delivery timeout
            result = kafkaProducer.send(new ProducerRecord<>(TopicNames.SOURCE_TOPIC.name, id, movieQuote.quote())).get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }

        log.atInfo()
                .setMessage("SendResult:")
                .addKeyValue("id", id)
                .addKeyValue("partition", result.getRecordMetadata().partition())
                .addKeyValue("topic", result.getRecordMetadata().topic())
                .addKeyValue("offset", result.getRecordMetadata().offset())
                .addKeyValue("timestamp", result.getRecordMetadata().timestamp())
                .log();
        return id;
    }
}
