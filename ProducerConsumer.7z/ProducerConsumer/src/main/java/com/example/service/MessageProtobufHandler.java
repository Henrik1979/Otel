package com.example.service;

import com.acme.Quote;
import com.example.TopicNames;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class MessageProtobufHandler {

    // https://codingharbour.com/apache-kafka/how-to-use-protobuf-with-apache-kafka-and-schema-registry/
    // https://github.com/codingharbour/kafka-protobuf?tab=readme-ov-file
    // See https://docs.confluent.io/platform/current/schema-registry/fundamentals/serdes-develop/serdes-protobuf.html

    private final KafkaTemplate<String, com.acme.Quote.MyRecord> kafkaProducer;

    public MessageProtobufHandler(@Autowired KafkaTemplate<String, com.acme.Quote.MyRecord> kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    @KafkaListener(topics = "source", groupId = "protobuf_group")
    public void handle(ConsumerRecord<String, String> record) {
        log.atInfo().setMessage("Received event").addKeyValue("key", record.key()).addKeyValue("message", record.value()).log();

        var key = record.key();
        var value = Quote.MyRecord.newBuilder()
                .setQuote(record.value())
                .setOther(
                        Quote.OtherRecord.newBuilder()
                                .setText("From pub / sub")
                                .build())
                .build();

        var producerRecord = new ProducerRecord<>(
                TopicNames.MOVIE_QUOTE_PROTOBUF_SINK_TOPIC.name,
                key,
                value);

        // Convert and forward to sink
        try {
            var res = kafkaProducer.send(producerRecord).get();

            log.atInfo()
                    .setMessage("Message send to MOVIE_QUOTE_SINK_TOPIC")
                    .addKeyValue("partition", res.getRecordMetadata().partition())
                    .addKeyValue("topic", res.getRecordMetadata().topic())
                    .addKeyValue("offset", res.getRecordMetadata().offset())
                    .addKeyValue("timestamp", res.getRecordMetadata().timestamp())
                    .log();

        } catch (Exception e) {
            log.atError().setMessage("Failed to to convert and forward message to protocol buffer sink").setCause(e).log();
        }
    }
}
