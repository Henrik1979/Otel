package com.example.service;

import dto.MovieQuoteDTO;

public interface MovieQuoteService {
    String createMovieQuote(MovieQuoteDTO movieQuote) ;
}
