package com.example.service;

import com.course.kafka.MovieQuote;
import com.course.kafka.MovieQuoteKey;
import com.example.TopicNames;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class MessageHandler {

    private final KafkaTemplate<MovieQuoteKey, MovieQuote> kafkaProducer;

    public MessageHandler(@Autowired KafkaTemplate<MovieQuoteKey, MovieQuote> kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    @KafkaListener(topics = "source")
    public void handle(ConsumerRecord<String, String> record) {
        log.atInfo().setMessage("Received event").addKeyValue("key", record.key()).addKeyValue("message", record.value()).log();

        // Convert and forward to sink
        try {
            var res = kafkaProducer.send(
                    new ProducerRecord<>(
                            TopicNames.MOVIE_QUOTE_SINK_TOPIC.name,
                            MovieQuoteKey.newBuilder().setQuoteKey(record.key()).build(),
                            MovieQuote.newBuilder().setQuote(record.value()).build()))
                    .get();

            log.atInfo()
                    .setMessage("Message send to MOVIE_QUOTE_SINK_TOPIC")
                    .addKeyValue("partition", res.getRecordMetadata().partition())
                    .addKeyValue("topic", res.getRecordMetadata().topic())
                    .addKeyValue("offset", res.getRecordMetadata().offset())
                    .addKeyValue("timestamp", res.getRecordMetadata().timestamp())
                    .log();

        } catch (Exception e) {
            log.atError().setMessage("Failed to to convert and forward message").setCause(e).log();
        }
    }
}