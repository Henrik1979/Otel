package com.example.rest;

import com.example.service.MovieQuoteService;
import dto.MovieQuoteDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/moviequotes") // http:/localhost:<port>/text
public class MovieQuoteDTOController {
    private final MovieQuoteService movieQuoteService;

    public MovieQuoteDTOController(@Autowired final MovieQuoteService movieQuoteService) {
        this.movieQuoteService = movieQuoteService;
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody MovieQuoteDTO movieQuoteDTO) {
        try {
            String id = movieQuoteService.createMovieQuote(movieQuoteDTO);

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(id);
        } catch (Exception e) {

            log.atError()
                    .setMessage("Failed to create quote")
                    .setCause(e)
                    .log();

            var errorMessage = ErrorMessage.fromException(e, "/moviequotes");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage);
        }
    }
}
