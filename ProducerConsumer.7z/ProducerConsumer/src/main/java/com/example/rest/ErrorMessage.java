package com.example.rest;

import java.time.Instant;

public record ErrorMessage(
        Instant timestamp,
        String message,
        String details) {

    public static ErrorMessage fromException(Exception e, String details){
        return new ErrorMessage(
                Instant.now(),
                e.getMessage(),
                details);
    }
}
