package com.example;

import com.acme.Quote;
import com.course.kafka.MovieQuote;
import com.course.kafka.MovieQuoteKey;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.TopicConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaConfig {

    @Value("${min.insync.replicas}")
    private String minInSyncReplicas;

   private  final KafkaProducerProperties properties;

    public KafkaConfig(@Autowired KafkaProducerProperties properties) {
        this.properties = properties;
    }

    @Bean
    public KafkaAdmin.NewTopics createTopics() {
        return new KafkaAdmin.NewTopics(
                TopicBuilder
                        .name(TopicNames.SOURCE_TOPIC.name)
                        .partitions(3)
                        .replicas(1)
                        .config(TopicConfig.MIN_IN_SYNC_REPLICAS_CONFIG, minInSyncReplicas)
                        .build(),
                TopicBuilder
                        .name(TopicNames.SINK_TOPIC.name)
                        .partitions(3)
                        .replicas(1)
                        .config(TopicConfig.MIN_IN_SYNC_REPLICAS_CONFIG, minInSyncReplicas)
                        .build(),
                TopicBuilder
                        .name(TopicNames.MOVIE_QUOTE_SINK_TOPIC.name)
                        .partitions(3)
                        .replicas(1)
                        .config(TopicConfig.MIN_IN_SYNC_REPLICAS_CONFIG, minInSyncReplicas)
                        .build(),
                TopicBuilder
                        .name(TopicNames.MOVIE_QUOTE_PROTOBUF_SINK_TOPIC.name)
                        .partitions(3)
                        .replicas(1)
                        .config(TopicConfig.MIN_IN_SYNC_REPLICAS_CONFIG, minInSyncReplicas)
                        .build()
        );
    }

    @Bean
    public ProducerFactory<String, Quote.MyRecord> protobufProducerFactory() {
        Map<String, Object> configProps = new HashMap<>(properties.getConfigProps());
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, io.confluent.kafka.serializers.protobuf.KafkaProtobufSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<String, Quote.MyRecord> kafkaProtobufTemplate() {
        return new KafkaTemplate<>(protobufProducerFactory());
    }

    @Bean
    public ProducerFactory<String, String> stringProducerFactory() {
        Map<String, Object> configProps = new HashMap<>(properties.getConfigProps());
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<String, String> kafkaStringTemplate() {
        return new KafkaTemplate<>(stringProducerFactory());
    }

    @Bean
    public ProducerFactory<MovieQuoteKey, MovieQuote> producerFactory() {
        Map<String, Object> configProps = new HashMap<>(properties.getConfigProps());
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, io.confluent.kafka.serializers.KafkaAvroSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, io.confluent.kafka.serializers.KafkaAvroSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<MovieQuoteKey, MovieQuote> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}