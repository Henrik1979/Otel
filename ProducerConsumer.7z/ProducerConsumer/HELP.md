https://chromewebstore.google.com/detail/postwoman-http-test/ieoejemkppmjcdfbnfphhpbfmallhfnc?hl=en-US&utm_source=ext_sidebar


http://localhost:9988/moviequotes

{
"quote" : "qwerty"
}