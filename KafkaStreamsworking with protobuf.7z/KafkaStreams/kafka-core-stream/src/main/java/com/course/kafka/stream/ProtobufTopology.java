package com.course.kafka.stream;

import com.course.kafka.stream.util.ProtobufSerde;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.confluent.kafka.streams.serdes.protobuf.KafkaProtobufSerde;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import model.MovieDTO;
import model.proto.MovieProto;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Named;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import static com.course.kafka.stream.TopicBean.*;
import static org.apache.kafka.common.serialization.Serdes.String;

@Slf4j
@Configuration
public class ProtobufTopology {
    private final StreamsBuilder builder;
    private final ProtobufSerde protobufSerde;

    @Autowired
    public ProtobufTopology(
            StreamsBuilder streamsBuilder,
            ProtobufSerde protobufSerde) {
        this.builder = streamsBuilder;
        this.protobufSerde = protobufSerde;
    }

    @PostConstruct
    public void run() {
        final var mapper = new ObjectMapper();

        final KafkaProtobufSerde<MovieProto.Movie> movieKafkaProtobufSerde = protobufSerde.getValueSerde(MovieProto.Movie.class);

        // ignore the topic , just for triggering an event!
        final var s = builder.stream(SOURCE_TOPIC,
                Consumed
                        .with(String(), String())
                        .withName(String.format("%s-%s-stream", SOURCE_TOPIC, ProtobufTopology.class.getSimpleName())));

        s.map((k, v) -> {
                    try {
                        MovieDTO movie = mapper.readValue(v, MovieDTO.class);

                        return new KeyValue<>(
                                k,
                                MovieProto.Movie.newBuilder()
                                        .setTitle(movie.title())
                                        .setReleaseYear(movie.releaseYear())
                                        .setReviewScore(movie.reviewScore())
                                        .setBudget(movie.budget())
                                        .build());

                    } catch (JsonProcessingException e) {
                        log.error("BOOM!!", e);
                        throw new RuntimeException(e);
                    }
                }, Named.as("My-awesome-Json-protobuf-mapper"))
                .to(
                        MOVIE_TOPIC,
                        Produced
                                .with(String(), movieKafkaProtobufSerde)
                                .withName("my-awesome-stream-output")
                );


        // Read the output into a new topology
        builder.stream(MOVIE_TOPIC,
                        Consumed
                                .with(
                                        Serdes.String(),
                                        movieKafkaProtobufSerde)
                                .withName("My-Awesome-Movie-Stream"))
                .map((k, v) -> {
                    return new KeyValue<>(k, v.getTitle());
                })
                .to(SINK_TOPIC, Produced.with(String(), String()).withName("Movie_name_output"));
    }
}