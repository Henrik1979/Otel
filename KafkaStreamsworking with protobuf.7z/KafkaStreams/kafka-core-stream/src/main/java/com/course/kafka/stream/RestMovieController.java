package com.course.kafka.stream;

import com.course.kafka.stream.util.ErrorMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import lombok.extern.slf4j.Slf4j;
import model.MovieDTO;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.concurrent.ExecutionException;

import static com.course.kafka.stream.TopicBean.SOURCE_TOPIC;


@Slf4j
@RestController
@RequestMapping("/movie")
public class RestMovieController {

    private final KafkaTemplate<String, String> kafkaProducer;

    public RestMovieController(@Autowired final KafkaTemplate<String, String> kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> helloWorld() throws JsonProcessingException {

        var data = new HashMap<String, Object>();
        data.put("Hello", "world!");
        String json = new ObjectMapper().writeValueAsString(data);
        return ResponseEntity.status(HttpStatus.CREATED).body(json);
    }


    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> create(@RequestBody MovieDTO movieQuoteDTO) throws JsonProcessingException {
        SendResult<String, String> result = null;
        var id = movieQuoteDTO.title();

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        var value = ow.writeValueAsString(movieQuoteDTO);

        try {
            log.atInfo().setMessage("Sending ProducerRecord").addKeyValue("id", id).log();

            result = kafkaProducer.send(new ProducerRecord<>(SOURCE_TOPIC, id, value)).get();
            log.atInfo()
                    .setMessage("SendResult:")
                    .addKeyValue("id", id)
                    .addKeyValue("partition", result.getRecordMetadata().partition())
                    .addKeyValue("topic", result.getRecordMetadata().topic())
                    .addKeyValue("offset", result.getRecordMetadata().offset())
                    .addKeyValue("timestamp", result.getRecordMetadata().timestamp())
                    .log();

            return ResponseEntity.status(HttpStatus.CREATED).body(id);
        } catch (InterruptedException | ExecutionException e) {
            var errorMessage = ErrorMessage.fromException(e, "/movie");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage);
        }
    }
}
