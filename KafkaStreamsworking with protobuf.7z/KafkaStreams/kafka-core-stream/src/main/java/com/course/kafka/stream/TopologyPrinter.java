package com.course.kafka.stream;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;

@Slf4j
@Configuration
public class TopologyPrinter {

    private final StreamsBuilderFactoryBean streamsBuilderFactoryBean;

    @Autowired
    public TopologyPrinter(StreamsBuilderFactoryBean streamsBuilderFactoryBean) {
        this.streamsBuilderFactoryBean = streamsBuilderFactoryBean;
    }


    @PostConstruct
    public void setupTopology() throws Exception {
        StreamsBuilder builder = streamsBuilderFactoryBean.getObject();
        if (builder == null) {
            log.error("Failed to retrieve StreamsBuilder instance.");
            return;
        }

        Topology topology = builder.build();
        log.info("Topology Description: {}", topology.describe().toString());
    }
}
