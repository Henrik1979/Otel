package model;

public record MovieDTO(
        String title,
        int releaseYear,
        float reviewScore,
        double budget) {
}