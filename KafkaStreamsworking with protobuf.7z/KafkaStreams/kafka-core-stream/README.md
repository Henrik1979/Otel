http://localhost:9021/clusters




POST

http://localhost/movie

{
"title": "77777",
"releaseYear": 2020,
"reviewScore": 3.1415,
"budget" :420.789
}