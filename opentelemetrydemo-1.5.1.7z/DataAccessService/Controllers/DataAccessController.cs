using System.Diagnostics;
using System.Net;
using DataAccessService.Repository;
using DataAccessService.Telemetry;
using Microsoft.AspNetCore.Mvc;
using Model;
using OpenTelemetry.Trace;

namespace DataAccessService.Controllers;

[ApiController]
[Route("api/database")]
public class DataAccessController : ControllerBase
{
  private readonly IProductRepository productRepository;
  private readonly IOtelMetrics metrics;

  public DataAccessController(IProductRepository productRepository, IOtelMetrics metrics)
  {
    this.productRepository = productRepository;
    this.metrics = metrics;
  }

  [HttpGet]
  [Route("Automatic")]
  public async Task<IActionResult> GetAutomaticInstrumentation()
  {
    try
    {
      var result = await productRepository.GetAllProducts();
      metrics.IncreaseIncomingCallCount(labels: metrics.CreateLabels(Request, HttpStatusCode.OK));
      return Ok(result);
    }
    catch(Exception)
    {
      metrics.IncreaseIncomingCallCount(labels: metrics.CreateLabels(Request, HttpStatusCode.InternalServerError));
      return BadRequest();
    }
  }

  [HttpGet]
  [Route("Manual")]
  public async Task<IActionResult> GetManualInstrumentation()
  {

    //Tracing parent can be found in header 
    var headers = Request.Headers.ToDictionary(h => h.Key, h => h.Value.ToString());

    // if you need to make a trace through message queue or other things that might not have a instrumentation lib 
    // use Propagators to inject a context into the header:
    // https://github.com/open-telemetry/opentelemetry-dotnet/tree/main/src/OpenTelemetry.Extensions.Propagators
    using var activity = OtelTracing.DataAccessActivitySource.StartActivity();

    try
    {
      IEnumerable<Product> products;
      using (activity?.AddEvent(new("Executing SQL in the database")))
      {
        products = await productRepository.GetAllProducts();
      }

      activity?.AddEvent(new("Returning data"));
      metrics.IncreaseIncomingCallCount(labels: metrics.CreateLabels(Request, HttpStatusCode.OK));

      return Ok(products);
    }
    catch (Exception e)
    {
      activity.RecordException(e);
      activity?.SetStatus(ActivityStatusCode.Error, e.Message);
      metrics.IncreaseIncomingCallCount(labels: metrics.CreateLabels(Request, HttpStatusCode.InternalServerError));
      return BadRequest(e);
    }
  }
}