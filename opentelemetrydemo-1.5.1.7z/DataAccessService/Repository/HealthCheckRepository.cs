﻿using Dapper;
using Microsoft.Data.SqlClient;

namespace DataAccessService.Repository;

public class HealthCheckRepository : IHealthCheckRepository
{
  private readonly string connectionString;

  public HealthCheckRepository(string connectionString)
  {
    this.connectionString = connectionString;
  }
  public async Task HealthCheck()
  {
    await using var connection = new SqlConnection(connectionString);
    connection.Open();
    await connection.QueryAsync("SELECT 1");
  }
}