﻿using Model;

namespace DataAccessService.Repository;

public interface IProductRepository
{
  Task<IEnumerable<Product>> GetAllProducts();
}