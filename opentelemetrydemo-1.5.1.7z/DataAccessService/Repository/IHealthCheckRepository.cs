﻿namespace DataAccessService.Repository;

  public interface IHealthCheckRepository
  {
    Task HealthCheck();
  }