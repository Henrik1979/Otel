﻿using Dapper;
using Microsoft.Data.SqlClient;
using Model;

namespace DataAccessService.Repository;

public class ProductRepository : IProductRepository
{
  private readonly string connectionString;

  public ProductRepository(string connectionString)
  {
    this.connectionString = connectionString;
  }

  public async Task<IEnumerable<Product>> GetAllProducts()
  {
    await using var connection = new SqlConnection(connectionString);
    connection.Open();
    const string sql = "SELECT * FROM products";
    return await connection.QueryAsync<Product>(sql);
  }
}