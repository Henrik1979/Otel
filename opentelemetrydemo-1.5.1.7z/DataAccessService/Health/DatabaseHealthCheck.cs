﻿using DataAccessService.Repository;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace DataAccessService.Health;

public class DatabaseHealthCheck : IHealthCheck
{
  private readonly IHealthCheckRepository healthCheckRepository;

  public DatabaseHealthCheck(IHealthCheckRepository healthCheckRepository)
  {
    this.healthCheckRepository = healthCheckRepository;
  }

  public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = new())
  {
    try
    {
      await healthCheckRepository.HealthCheck();
      return HealthCheckResult.Healthy();
    }
    catch (Exception e)
    {
      return HealthCheckResult.Unhealthy("Database unreachable", e);
    }
  }
}