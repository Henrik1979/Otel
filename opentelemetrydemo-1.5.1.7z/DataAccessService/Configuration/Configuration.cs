﻿namespace DataAccessService.Configuration;

public class Configuration : IConfiguration
{
  public string ServiceName { get; init; } = null!;
  public string HealthCheckEndpoint { get; init; } = null!;
  public string OTLPEndpoint { get; init; } = null!;
  public string ConnectionString { get; init; } = null!;

  public void PrintProperties()
  {
    var properties = typeof(Configuration).GetProperties();
    var maxPropertyNameLength =  properties.Select(property => property.Name.Length).Prepend(0).Max();

    foreach (var property in properties)
    {
      var propertyName = property.Name;
      var formattedPropertyName = propertyName.PadRight(maxPropertyNameLength, '.');
      var propertyValue = property.GetValue(this);
      Console.WriteLine($"{formattedPropertyName}: {propertyValue}");
    }
  }

  private Configuration() {}

  public static IConfiguration Create()
  {
    var configuration = new ConfigurationBuilder()
      .SetBasePath(AppContext.BaseDirectory)
      .AddJsonFile("appsettings.json", optional: true)
      .Build();

    return new Configuration
    {
      ServiceName = Environment.GetEnvironmentVariable("SERVICE_NAME") ?? configuration.GetValue<string>("ServiceName")!,
      HealthCheckEndpoint = Environment.GetEnvironmentVariable("HEALTH_CHECK_ENDPOINT") ?? configuration.GetValue<string>("Endpoints:HealthCheck")!,
      OTLPEndpoint = Environment.GetEnvironmentVariable("OTLP_ENDPOINT") ?? configuration.GetValue("OpenTelemetry:Endpoint", "http://localhost:9045")!,
      ConnectionString = Environment.GetEnvironmentVariable("CONNECTION_STRING") ?? configuration.GetValue<string>("Database:ConnectionString")!,
    };
  }
}