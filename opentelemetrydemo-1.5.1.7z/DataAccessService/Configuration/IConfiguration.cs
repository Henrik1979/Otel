﻿namespace DataAccessService.Configuration;

// Note: instead of using our custom IConfiguration interface we could write to Microsoft.Extensions.Configuration.IConfiguration
// This way our configuration would word as we were using appsettings - there are some issues
public interface IConfiguration
{
  public string ServiceName { get; }
  public string HealthCheckEndpoint { get; }
  public string OTLPEndpoint { get; }
  public string ConnectionString { get; }

  void PrintProperties();
}