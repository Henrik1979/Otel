## Build image
docker build -t data-access-service ../ -f .\Dockerfile 

## Run if not used in docker compose
docker run --rm -e CONNECTION_STRING="Data Source=sqlserver;User ID=sa;Password=Pass@Word1;TrustServerCertificate=True;" --network oteldemo_default -p 7070:7070 data-access-service