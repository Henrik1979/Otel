using DataAccessService.Health;
using DataAccessService.Repository;
using DataAccessService.Telemetry;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using DataAccessService.Configuration;

var webApplicationOptions = new WebApplicationOptions
{
  ContentRootPath = AppContext.BaseDirectory,
  Args = args,
};

var builder = WebApplication.CreateBuilder(webApplicationOptions);
builder.WebHost.UseUrls("http://0.0.0.0:7070");

var configuration = Configuration.Create();
configuration.PrintProperties();
builder.Services.AddSingleton(_ => configuration);

builder.Services.AddHealthChecks()
   // Add custom health check, this is just for the demo - you should just download a nuget package: "aspnetcore .healthchecks." as shown below
  .AddCheck<DatabaseHealthCheck>(nameof(DatabaseHealthCheck))
  //.AddSqlServer(connectionString) // Do this in production for sql server health check
 ;

var endpointsToIgnore = new List<string>
{
  configuration.HealthCheckEndpoint,
  "swagger"
};

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<IProductRepository>(_ => new ProductRepository(configuration.ConnectionString));
builder.Services.AddSingleton<IHealthCheckRepository>(_ => new HealthCheckRepository(configuration.ConnectionString));
builder.Services.AddSingleton<IOtelMetrics>(_ => new OtelMetrics(configuration.ServiceName));
builder.Services.AddOpenTelemetry()
  .WithTracing(tracerProviderBuilder => tracerProviderBuilder
    .AddOtlpExporter(options =>
    {
      options.Endpoint = new Uri(configuration.OTLPEndpoint);
    })
   .AddSource(OtelTracing.SourceName)
   // This method adds instrumentation for ASP.NET Core applications, allowing OpenTelemetry to trace requests and activities within an ASP.NET Core application.
   .AddAspNetCoreInstrumentation(options =>
   {
      // Don't add traces for health checks and swagger calls
      options.Filter = (httpContext) =>
      {
        // If filter returns true the request is collected
        // If filter returns false or throws an exception the request is NOT collected
        return endpointsToIgnore.All(path => httpContext.Request.Path.Value!.IndexOf(path, StringComparison.OrdinalIgnoreCase) == -1);
      };
   })
    .SetResourceBuilder(TracingResourceBuilder.GetResourceBuilder())
    /*
     * Get sql query information.
     * This doesn't support Dapper, only ADO.NET provider: https://github.com/DapperLib/Dapper/issues/1355
     * You still get the trace, but the SQL isn't included 
     */
    .AddSqlClientInstrumentation()
   )
  .WithMetrics(meterProviderBuilder => meterProviderBuilder
    .ConfigureResource(resource => resource
      .AddService(configuration.ServiceName))
    .AddMeter(configuration.ServiceName)
    .AddOtlpExporter(options =>
    {
      options.Endpoint = new Uri(configuration.OTLPEndpoint);
    })
    // https://github.com/open-telemetry/opentelemetry-dotnet-contrib/tree/main/src/OpenTelemetry.Instrumentation.Runtime
    .AddRuntimeInstrumentation()
    // https://github.com/open-telemetry/opentelemetry-dotnet-contrib/tree/main/src/OpenTelemetry.Instrumentation.Process
    .AddProcessInstrumentation()
    //https://github.com/open-telemetry/opentelemetry-dotnet/tree/main/src/OpenTelemetry.Instrumentation.AspNetCore
    .AddAspNetCoreInstrumentation(options =>
    {
      //Don't store metrics about health check endpoint or swagger
      options.Filter = (s, context) =>
      {
        // If filter returns true the request is collected
        // If filter returns false or throws an exception the request is NOT collected
        return endpointsToIgnore.All(path => context.Request.Path.Value!.IndexOf(path, StringComparison.OrdinalIgnoreCase) == -1);
      };
    })
  );

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

//set path for health check , let liveness and readiness probes access it
app.MapHealthChecks(configuration.HealthCheckEndpoint, new HealthCheckOptions
{
  ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});


app.UseAuthorization();
app.MapControllers();
app.Run();