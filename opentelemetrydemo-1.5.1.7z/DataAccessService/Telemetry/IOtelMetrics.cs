﻿using System.Net;

namespace DataAccessService.Telemetry;

public interface IOtelMetrics
{
  public void IncreaseIncomingCallCount(int count = 1, params KeyValuePair<string, object?>[] labels);

  KeyValuePair<string, object?>[] CreateLabels(HttpRequest request, HttpStatusCode responseCode, params KeyValuePair<string, object?>[] customLabels)
  {
    var keyValuePairs = new List<KeyValuePair<string, object?>>
    {
      new("http.route", request.Path.Value ?? string.Empty),
      new("http.request.method", request.Method),
      new("http.response.status_code", (int)responseCode)
    };

    keyValuePairs.AddRange(customLabels);
    return keyValuePairs.ToArray();
  }
}