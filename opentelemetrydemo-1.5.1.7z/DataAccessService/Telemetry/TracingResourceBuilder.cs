﻿using System.Runtime.InteropServices;
using OpenTelemetry.Resources;

namespace DataAccessService.Telemetry;

public static class TracingResourceBuilder
{
  public static ResourceBuilder GetResourceBuilder()
  {
    var resourceBuilder = ResourceBuilder.CreateDefault();

    // Add custom data that will be added to "tags" on every activity  
    var customAttributes = new List<KeyValuePair<string, object>>
      {
        new ("dotnet.runtime.version", RuntimeInformation.FrameworkDescription), // Add .NET runtime version
        new ("os.description", RuntimeInformation.OSDescription), // Add operating system information
      };

    resourceBuilder.AddAttributes(customAttributes);
    resourceBuilder.AddService(serviceName: OtelTracing.SourceName, serviceVersion: OtelTracing.Version);
    return resourceBuilder;
  }
}