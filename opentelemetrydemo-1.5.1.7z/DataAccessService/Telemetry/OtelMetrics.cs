﻿using System.Diagnostics.Metrics;

namespace DataAccessService.Telemetry;

public class OtelMetrics : IOtelMetrics
{
  private Counter<int> IncomingCallCounter { get; }

  public OtelMetrics(string meterName)
  {
    var meter = new Meter(meterName);
    IncomingCallCounter = meter.CreateCounter<int>(name: "http.incoming.requests.total", unit: "requests", description: "http requests to the service");
  }

  public void IncreaseIncomingCallCount(int count = 1, params KeyValuePair<string, object?>[] labels) => IncomingCallCounter.Add(count, labels);
}