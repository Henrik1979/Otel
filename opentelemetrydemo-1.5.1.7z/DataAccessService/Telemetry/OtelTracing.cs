﻿using System.Diagnostics;

namespace DataAccessService.Telemetry;

public class OtelTracing
{
  public const string SourceName = "Database accesss API";
  public const string Version = "0.1";

  public static readonly ActivitySource DataAccessActivitySource = new(SourceName);
}