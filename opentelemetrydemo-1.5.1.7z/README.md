# Demo

## Warning

Before using spans in production read the following links:

### Sampling
https://opentelemetry.io/docs/concepts/sampling/

### Tail Sampling
https://opentelemetry.io/blog/2022/tail-sampling/

### Trace Context 
https://www.w3.org/TR/trace-context/

## Scaling the collector
https://opentelemetry.io/docs/collector/scaling/

## Vmmem 
If your VMMem process won't release memory after running use the following command to reboot WSL (Windows subsystem Linux):
```Get-Service LxssManager | Restart-Service```

## Setup

![](./Diagram.png)


## Docker

|Commands|Note|
|-|-|
|```docker compose config```|prints the full configuration|
|```docker ps --filter "health=unhealthy"```||
|```docker inspect <container_id>```|See healthcheck section to inspect errors|
|```docker stats```|Display a live stream of containers resource usage statistics see [doc](https://docs.docker.com/engine/reference/commandline/stats/)|

### Start up

|Commands|Note|
|-|-|
|```docker-compose up -d --build > build.log```|This will rebuild your images and output build information to log file, very useful for finding errors|
|```docker compose up --build -d```|This will rebuild your images|
|```docker compose up -d```||

### Shutdown 

|Commands|Note|
|-|-|
|```docker compose down ```|This will shutdwon containers, but not delete data in volumes|
|```docker compose up -v```|Shutdown and delete volumes|


### Clean up 

|Commands|Note|
|-|-|
|```docker system prune ```||
|```docker volumes prune```||

## OTel

### Tutorials

|||
|-|-|
|https://opentelemetry.io/docs/instrumentation/net/getting-started/|.NET getting started guide|
|https://github.com/open-telemetry/opentelemetry-dotnet/tree/main/examples|Examples from opentelemetry-dotnet|
|https://www.mytechramblings.com/posts/getting-started-with-opentelemetry-metrics-and-dotnet-part-1/ ||
|https://www.mytechramblings.com/posts/getting-started-with-opentelemetry-metrics-and-dotnet-part-2/ ||
|https://signoz.io/blog/opentelemetry-collector-complete-guide/||
|https://github.com/karlospn/opentelemetry-tracing-demo|Message queue example with PropagationContext example (a bit outdated)|


## OTel Exporter

### Configuration
https://opentelemetry.io/docs/specs/otel/protocol/exporter/#configuration-options

## OTel collector

### Collector metrics

||
|-|
|http://localhost:8888/metrics |
|http://localhost:8889/metrics |

### Prometheus 

#### Endpoints
http://localhost:9090/

#### commands
|Command|Description|
|-|-|
|```Invoke-WebRequest -Uri http://localhost:9090/-/reload -Method POST -UseBasicParsing```|Reload configuration|

## Zipkin
http://localhost:9411/zipkin/

## Jaeger
http://localhost:16686/search

## Grafana
|Link|User|Password|
|-|-|-|
|http://localhost:3000/login|```admin```|```admin```|

## WebAPI

|Endpoints|Description|
|-|-|
|http://localhost:8080/swagger/index.html|Swagger|
|http://localhost:8080/_health|Health check|
|http://localhost:8080/metrics|Metrics (prometheus exporter)|

## DataAccessService
|Endpoints|Description|
|-|-|
|http://localhost:7070/swagger/index.html|Swagger|
|http://localhost:7070/_health|Health check|

## SQL server

|IP|User|Password|
|-|-|-|
|127.0.0.1|```sa```|```Pass@Word1```|

## Elasticsearch
http://localhost:9200/

## Kibana
||
|-|
|http://localhost:5601 |
|http://localhost:5601/app/dev_tools#/console |

### Commands

```
GET /_cat/indices?v&pretty

GET /log_index*/_search
{
  "query": {
    "bool": {
      "must_not": [
        { "wildcard": { "Attributes.EndpointName": "*health*" } },
        { "wildcard": { "Attributes.Path": "*health*" } }
      ]
    }
  }
}


# This doesn't work - timestamp is set to late and therefore the index value will be post fixed with null - How to do this needs to be investigated more
PUT _ingest/pipeline/redirect_to_today
{
  "description": "Redirects documents to index",
  "processors": [
    {
      "set": {
        "field": "_source.ingest_time",
        "value": "{{_ingest.timestamp}}"
      }
    },
    {
      "set": {
        "field": "ctx.test",
        "value": "{{_ingest.timestamp}}"
      }
    },
    {
      "script": {
        "lang": "painless",
        "source": """
        ctx._index = ctx._index + ctx.timestamp;
        """
      }
    }
  ]
}

POST log_index/_doc/1?pipeline=redirect_to_today
{
  "message": "This is a test document"
}

GET  /log_index/_doc/1



http://localhost:9200/foo/_search?pretty=true&q={'matchAll':{''}}
```

## Windows events

To export windows event: ```host -> logstash -> elasticsearch``` 
You have to download [winlogbeat-8.8.x-windows-x86_64](https://www.elastic.co/downloads/beats/winlogbeat) configure logstash / kibana endpoints and start winlogbeat. Logs will then be exported to elasticsearch where they can be view in the dashboard.

An example configuration can bee seen [here](./Configurations/winlogbeat/winlogbeat.yml)

if you want to use the dashboards:

```yaml
setup.dashboards.enabled: true

# Use the command to configure the dashboard
.\winlogbeat.exe setup --dashboards

# Start the export:
winlogbeat.exe -c  ./Configurations/winlogbeat/winlogbeat.yml
```

## JMeter
https://jmeter.apache.org/download_jmeter.cgi
