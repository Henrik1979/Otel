﻿using System.Reflection;
using DbUp;

var connectionString = Environment.GetEnvironmentVariable("CONNECTION_STRING") 
                       ?? "Data Source=127.0.0.1;User ID=sa;Password=Pass@Word1;TrustServerCertificate=True;";

ArgumentException.ThrowIfNullOrEmpty(connectionString);

var upgrader =
  DeployChanges
    .To
    .SqlDatabase(connectionString)
    .WithScriptsEmbeddedInAssembly(Assembly.GetExecutingAssembly())
    .LogToConsole()
    .JournalToSqlTable("dbo", "SchemaVersions")
    .Build();

var result = upgrader.PerformUpgrade();

if (!result.Successful)
{
  Console.ForegroundColor = ConsoleColor.Red;
  Console.Write(connectionString);
  Console.WriteLine(result.Error);
  Console.ResetColor();
#if DEBUG
  Console.ReadLine();
#endif
  return -1;
}

Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("Success!");
Console.ResetColor();
return 0;