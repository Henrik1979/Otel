## Build image
docker build -t database-builder:1.0.0 .

## Run if not used in docker compose
docker run --rm -e CONNECTION_STRING="Data Source=sqlserver;User ID=sa;Password=Pass@Word1;TrustServerCertificate=True;" --network oteldemo_default database-builder:1.0.0