﻿SET NOCOUNT ON;

DECLARE @counter INT = 1;

WHILE @counter <= 50
BEGIN
    INSERT INTO products (ProductName, price)
    VALUES
        (CONCAT('Product', @counter), ABS(CHECKSUM(NEWID())) % 1000 + 1);
    
    SET @counter = @counter + 1;
END;

