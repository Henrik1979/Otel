﻿USE [master]
GO

CREATE TABLE products (
	ProductId int identity(1,1) primary key,
	ProductName nvarchar(50),
	Price int
)
