﻿using OpenTelemetry;
using OpenTelemetry.Metrics;

namespace WebAPI.Exporter;

public class FileMetricExporter : BaseExporter<Metric>
{
  private readonly string filePath;

  public FileMetricExporter(string filePath)
  {
    this.filePath = filePath;
  }

  public override ExportResult Export(in Batch<Metric> metrics)
  {
    using var writer = File.AppendText(filePath);

    foreach (var metric in metrics)
    {
      switch (metric.MetricType)
      {
        case MetricType.LongSum:

          foreach (ref readonly var metricPoint in metric.GetMetricPoints())
          {
            var entry = $"Time: {DateTimeOffset.UtcNow} MeterName: {metric.MeterName} Name: {metric.Name} MetricType: {metric.MetricType} Value: {metricPoint.GetSumLong()}";
            writer.WriteLine(entry);
          }
          break;

        //TODO
        case MetricType.DoubleSum:
        case MetricType.LongGauge:
        case MetricType.DoubleGauge:
        case MetricType.Histogram:
        case MetricType.ExponentialHistogram:
        case MetricType.LongSumNonMonotonic:
        case MetricType.DoubleSumNonMonotonic:
        default:
          break;
      }
    }

    return ExportResult.Success;
  }
}