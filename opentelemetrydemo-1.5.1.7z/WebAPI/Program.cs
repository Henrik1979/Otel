using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using OpenTelemetry.Exporter;
using OpenTelemetry.Trace;
using OpenTelemetry.Logs;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using WebAPI.Configuration;
using WebAPI.Exporter;
using WebAPI.Telemetry;


var webApplicationOptions = new WebApplicationOptions
{
  ContentRootPath = AppContext.BaseDirectory,
  Args = args,
};

var builder = WebApplication.CreateBuilder(webApplicationOptions);
var configuration = Configuration.Create();
configuration.PrintProperties();
builder.Services.AddSingleton(_ => configuration);

var endpointsToIgnore = new List<string>
{
  configuration.HealthCheckEndpoint,
  configuration.MetricsEndpoint,
  "swagger"
};

//If you need to bypass the OTel collector you can use the following nuget packages and use the native exporters:
// OTel.Exporter.Elasticsearch.Http (Logging) https://github.com/Dheerajcode2016/opentelemetry-elk-exporter
// OpenTelemetry.Exporter.Zipkin (Tracing) https://github.com/open-telemetry/opentelemetry-dotnet
// OpenTelemetry.Exporter.Jaeger (Tracing) https://github.com/open-telemetry/opentelemetry-dotnet

builder.WebHost.UseUrls("http://0.0.0.0:8080");
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

//Health checks are a must, otherwise traffic can't be re routed to healthy applications in the cluster.
//See DataAccessService for custom health check
builder.Services.AddHealthChecks();
builder.Services.AddSingleton<IOtelMetrics>(_ => new OtelMetrics(configuration.ServiceName));
builder.Services.AddSwaggerGen();
builder.Services.AddSwaggerGen(opts =>
{
  opts.SwaggerDoc("v1", new OpenApiInfo()
  {
    Title = configuration.ServiceName,
  });
});

// Configure OpenTelemetry Logging.
// See https://www.youtube.com/watch?v=QU_o24OZeIw
// https://github.com/open-telemetry/opentelemetry-dotnet/tree/main/docs/logs

// DO call ClearProviders otherwise you'll be in a world of pain and suffering 
builder.Logging.ClearProviders();

builder.Logging.AddOpenTelemetry(options =>
{
  options.SetResourceBuilder(ResourceBuilder.CreateDefault().AddService(configuration.ServiceName));
  options.AddOtlpExporter(config =>
  {
    config.Endpoint = new Uri(configuration.OTLPEndpoint);
    config.Protocol = OtlpExportProtocol.Grpc;
  });
  options.AddConsoleExporter();
  //Issue: this code worked in v 1.4+ but for some reason it doesn't in 1.5. Now we configure it by hand
  //builder.Logging.AddConfiguration(configuration.GetSection("Logging"));
  //builder.Logging.AddConfiguration(configuration.GetSection("Logging:OpenTelemetry"));
  options.IncludeFormattedMessage = configuration.IncludeFormattedMessage;
  options.IncludeScopes = configuration.IncludeScopes;
  options.ParseStateValues = configuration.ParseStateValues;
});

builder.Services.AddOpenTelemetry()
  //  This method configures the tracer provider for OpenTelemetry.
  //  The parameter is a lambda expression that allows you to further configure the tracer provider.
  .WithTracing(tracerProviderBuilder => tracerProviderBuilder
    // This method adds an OpenTelemetry Protocol (OTLP) exporter to send the collected traces to a specific endpoint.
    // OTLP is a standard protocol for transmitting telemetry data.
    .AddOtlpExporter(options =>
    {
      options.Endpoint = new Uri(configuration.OTLPEndpoint);
    })
    // This method adds a source name to specify which events or components to trace.
    // You have to register your ActivitySource, otherwise it won't have any listeners and no spans will be saved
    .AddSource(OtelTracing.SourceName)
    // This method sets the sampling strategy for traces.
    // Sampling is used to reduce the volume of collected traces for performance reasons.
    // Here, it uses the TraceIdRatioBasedSampler with a sampling ratio of 1.00 (100%)
    // For custom checks read this article: https://medium.com/opentelemetry/opentelemetry-beyond-getting-started-5ac43cd0fe26
    .SetSampler(new TraceIdRatioBasedSampler(configuration.SpanSamplingRatio))

    // This method adds instrumentation for ASP.NET Core applications, allowing OpenTelemetry to trace requests and activities within an ASP.NET Core application.
    .AddAspNetCoreInstrumentation(options =>
    {
      // Don't add traces for health checks and swagger calls
      options.Filter = (httpContext) =>
      {
        // If filter returns true the request is collected
        // If filter returns false or throws an exception the request is NOT collected
        return endpointsToIgnore.All(path => httpContext.Request.Path.Value!.IndexOf(path, StringComparison.OrdinalIgnoreCase) == -1);
      };

    })
    // This method adds instrumentation for HttpClient, enabling tracing of outgoing HTTP requests made by the application.
    .AddHttpClientInstrumentation()
    // This method sets the resource builder for the tracer provider. A resource represents the entity or service that generates telemetry data
    .SetResourceBuilder(TracingResourceBuilder.GetResourceBuilder())
  ).
  WithMetrics(meterProviderBuilder => meterProviderBuilder
    .ConfigureResource(resource => resource
      // Adds service name to metrics 
      .AddService(configuration.ServiceName))
    .AddMeter(configuration.ServiceName)
    // this is not needed since OTel collector is scraped - but nice to have for debugging: https://github.com/open-telemetry/opentelemetry-dotnet
    // Remember to register Prometheus scraping middleware using the UseOpenTelemetryPrometheusScrapingEndpoint
    .AddPrometheusExporter(options => 
    {
      options.ScrapeEndpointPath = configuration.MetricsEndpoint;

    }) 
    .AddOtlpExporter(options =>
    {
      options.Endpoint = new Uri(configuration.OTLPEndpoint);
    })
    // https://github.com/open-telemetry/opentelemetry-dotnet-contrib/tree/main/src/OpenTelemetry.Instrumentation.Runtime
    .AddRuntimeInstrumentation()
    // https://github.com/open-telemetry/opentelemetry-dotnet-contrib/tree/main/src/OpenTelemetry.Instrumentation.Process
    .AddProcessInstrumentation()
    //https://github.com/open-telemetry/opentelemetry-dotnet/tree/main/src/OpenTelemetry.Instrumentation.AspNetCore
    .AddAspNetCoreInstrumentation(options =>
    {
      //Don't store metrics for health check, prometheus or swagger
      options.Filter = (s, context) =>
      {
        // If filter returns true the request is collected
        // If filter returns false or throws an exception the request is NOT collected
        return endpointsToIgnore.All(path => context.Request.Path.Value!.IndexOf(path, StringComparison.OrdinalIgnoreCase) == -1);
      };
    })
    // Example of how to configure histogram with custom bucket size
    .AddView(
      instrumentName: OtelMetrics.MetricTimeHistogramName,
      new ExplicitBucketHistogramConfiguration { Boundaries = new double[] {5, 10, 15, 25, 50, 75, 250 } })
    // Add custom exporter for metric 
    .AddReader(new PeriodicExportingMetricReader(new FileMetricExporter("./metric.log"), exportIntervalMilliseconds: 10000))
  );

var app = builder.Build();

// Register Prometheus scraping middleware
app.UseOpenTelemetryPrometheusScrapingEndpoint();

// Configure the HTTP request pipeline. (Middleware is sequential => ordering matters!)
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

// The code will just return "Healthy" as string - in some a better reply is needed
//app.MapHealthChecks("/_health"); //set path for health check , let liveness and readiness probes access it 
app.MapHealthChecks(configuration.HealthCheckEndpoint, new HealthCheckOptions
{
  // This will give more information:
  // {"status":"Healthy","totalDuration":"00:00:00.0007787","entries":{}}
  ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});

app.UseRouting();
app.UseAuthorization();
app.UseEndpoints(endpoints =>
{
  _ = endpoints.MapControllers();

  // Catch-all route
  endpoints.MapFallback(context =>
  {
    context.Response.StatusCode = 404;
    return context.Response.WriteAsync($"Route: \"{context.Request.Path}\" not found :/");
  });
});

app.Run();