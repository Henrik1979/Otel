﻿using Microsoft.AspNetCore.Mvc;
using Model;
using OpenTelemetry.Trace;
using System.Diagnostics;
using System.Net;
using WebAPI.Telemetry;

namespace WebAPI.Controllers;

[ApiController]
[Route("api/devices")]
//[Route("api/[controller]")] // gets the name of the controller (without controller in the end) this can be dangerous in refactoring because the endpoint can change
public class DeviceController : ControllerBase
{
  private static readonly HttpClient Client = new();

  private readonly ILogger<DeviceController> logger;
  private readonly Configuration.IConfiguration configuration;
  private readonly IOtelMetrics metrics;

  public DeviceController(ILogger<DeviceController> logger, Configuration.IConfiguration configuration, IOtelMetrics metrics)
  {
    this.logger = logger;
    this.configuration = configuration;
    this.metrics = metrics;
  }

  [HttpGet]
  [Route("metric")] // without s since there's a "metrics" filter on AddAspNetCoreInstrumentation
  public async Task<IActionResult> GetDevicesMetric()
  {
    return await metrics.RecordMetricExecutingTime<IActionResult>(async () =>
    {
      try
      {
        var uriBuilder = new UriBuilder(configuration.DataAccessEndpoint)
        {
          Path = "api/database/Automatic"
        };

        var response = await Client.GetAsync(uriBuilder.ToString());

        if (response.IsSuccessStatusCode)
        {
          var products = await response.Content.ReadFromJsonAsync<IEnumerable<Product>>();
          metrics.IncreaseIncomingCallCount(labels: metrics.CreateLabels(Request, HttpStatusCode.OK)!);
          return new JsonResult(products);
        }

        logger.LogError("{method}: call to {DataAccessEndpoint} failed. Error: {error}. Message: {message} ", nameof(GetDevicesAutomaticSpanInstrumentation), configuration.DataAccessEndpoint, response.StatusCode, response.ReasonPhrase);
        metrics.IncreaseIncomingCallCount(labels: metrics.CreateLabels(Request, response.StatusCode)!);
        return BadRequest(new { error = response.StatusCode, message = response.ReasonPhrase });
      }
      catch (Exception ex)
      {
        logger.LogError(ex, "Failed to call  {DataAccessEndpoint}", configuration.DataAccessEndpoint);
        metrics.IncreaseIncomingCallCount(labels: metrics.CreateLabels(Request, HttpStatusCode.InternalServerError)!);
        return BadRequest(new { error = "An unexpected error occurred.", message = ex.Message });
      }
    });
  }

  [HttpGet]
  [Route("automatic_span_instrumentation")]
  public async Task<IActionResult> GetDevicesAutomaticSpanInstrumentation()
  {
    // Automatic Instrumentation
    // https://opentelemetry.io/docs/instrumentation/net/libraries/
    try
    {

      var uriBuilder = new UriBuilder(configuration.DataAccessEndpoint)
      {
        Path = "api/database/Automatic"
      };

      var response = await Client.GetAsync(uriBuilder.ToString());

      if (response.IsSuccessStatusCode)
      {
        var products = await response.Content.ReadFromJsonAsync<IEnumerable<Product>>();
        return new JsonResult(products);
      }

      logger.LogError("{method}: call to {DataAccessEndpoint} failed. Error: {error}. Message: {message} ", nameof(GetDevicesAutomaticSpanInstrumentation), configuration.DataAccessEndpoint, response.StatusCode, response.ReasonPhrase);
      return BadRequest(new { error = response.StatusCode, message = response.ReasonPhrase });
    }
    catch (Exception ex)
    {
      logger.LogError(ex, "Failed to call  {DataAccessEndpoint}", configuration.DataAccessEndpoint);
      return BadRequest(new { error = "An unexpected error occurred.", message = ex.Message });
    }
  }

  [HttpGet]
  [Route("manual_span_instrumentation")]
  public async Task<IActionResult> GetDevicesManualSpanInstrumentation()
  {
    // Manual Instrumentation
    // https://opentelemetry.io/docs/instrumentation/net/manual/
    using var activity = OtelTracing.WebAPIActivitySource.StartActivity();
    activity?.AddTag(key: "My custom tag", value: "My custom tag value");

    if (logger.IsEnabled(LogLevel.Information))
    {
      logger.LogInformation("{method}: received call from {remoteCaller}  ", nameof(GetDevicesManualSpanInstrumentation), HttpContext.Connection.RemoteIpAddress);
    }

    try
    {
      var uriBuilder = new UriBuilder(configuration.DataAccessEndpoint)
      {
        Path = "api/database/Manual"
      };

      HttpResponseMessage response;

      using (activity?.AddEvent(new ActivityEvent("Calling Database service")))
      {
        response = await Client.GetAsync(uriBuilder.ToString());
      }

      if (response.IsSuccessStatusCode)
      {
        using (activity?.AddEvent(new ActivityEvent("Parsing returned data")))
        {
          var products = await response.Content.ReadFromJsonAsync<IEnumerable<Product>>();
          return new JsonResult(products);
        }
      }

      logger.LogError("{method}: call to {DataAccessEndpoint} failed. Error: {error}. Message: {message} ", nameof(GetDevicesManualSpanInstrumentation), configuration.DataAccessEndpoint, response.StatusCode, response.ReasonPhrase);
      activity?.SetStatus(ActivityStatusCode.Error, $"Something bad happened: {response.ReasonPhrase}");
      return BadRequest(new { error = response.StatusCode, message = response.ReasonPhrase });

    }
    catch (Exception ex)
    {
      activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
      activity.RecordException(ex);
      logger.LogError(ex, "Failed to call  {DataAccessEndpoint}", configuration.DataAccessEndpoint);
      return BadRequest(new { error = "An unexpected error occurred.", message = ex.Message });
    }
  }
}