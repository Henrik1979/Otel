﻿namespace WebAPI.Configuration;

// Note: instead of using our custom IConfiguration interface we could write to Microsoft.Extensions.Configuration.IConfiguration
// This way our configuration would word as we were using appsettings
public interface IConfiguration
{
  public string ServiceName { get; }
  public string OTLPEndpoint { get; }
  public string HealthCheckEndpoint { get; }
  public string MetricsEndpoint { get; }
  public string DataAccessEndpoint { get; }
  public bool IncludeFormattedMessage { get; }
  public bool IncludeScopes { get; }
  public bool ParseStateValues { get; }
  public double SpanSamplingRatio { get; }

  void PrintProperties();
}