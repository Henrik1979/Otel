﻿namespace WebAPI.Configuration;

public class Configuration : IConfiguration
{
  public string ServiceName { get; init; } = null!;
  public string OTLPEndpoint { get; init; } = null!;
  public string HealthCheckEndpoint { get; init; } = null!;
  public string MetricsEndpoint { get; init; } = null!;
  public string DataAccessEndpoint { get; init; } = null!;
  public bool IncludeFormattedMessage { get; init; }    
  public bool IncludeScopes { get; init; }
  public bool ParseStateValues { get; init; }
  public double SpanSamplingRatio { get; init; }

  public void PrintProperties()
  {
    var properties = typeof(Configuration).GetProperties();
    var maxPropertyNameLength =  properties.Select(property => property.Name.Length).Prepend(0).Max();

    foreach (var property in properties)
    {
      var propertyName = property.Name;
      var formattedPropertyName = propertyName.PadRight(maxPropertyNameLength, '.');
      var propertyValue = property.GetValue(this);
      Console.WriteLine($"{formattedPropertyName}: {propertyValue}");
    }
  }

  private Configuration() {}

  public static IConfiguration Create()
  {
    var configuration = new ConfigurationBuilder()
      .SetBasePath(AppContext.BaseDirectory)
      .AddJsonFile("appsettings.json", optional: true)
      .Build();

    return new Configuration
    {
      ServiceName = Environment.GetEnvironmentVariable("SERVICE_NAME") ?? configuration.GetValue<string>("ServiceName")!,
      OTLPEndpoint = Environment.GetEnvironmentVariable("OTLP_ENDPOINT") ?? configuration.GetValue<string>("OpenTelemetry:Endpoint")!,
      DataAccessEndpoint = Environment.GetEnvironmentVariable("DATA_ACCESS_ENDPOINT") ?? configuration.GetValue<string>("Endpoints:DataAccess")!,
      HealthCheckEndpoint = Environment.GetEnvironmentVariable("HEALTH_CHECK_ENDPOINT") ?? configuration.GetValue<string>("Endpoints:HealthCheck")!,
      MetricsEndpoint = Environment.GetEnvironmentVariable("METRICS_ENDPOINT") ?? configuration.GetValue<string>("Endpoints:Metrics")!,
      
      IncludeFormattedMessage = bool.TryParse(Environment.GetEnvironmentVariable("OTLP_LOGGING_INCLUDE_FORMATTED_MESSAGE"), out var includeFormattedMessage)
        ? includeFormattedMessage : configuration.GetValue("Logging:OpenTelemetry:IncludeFormattedMessage", true),

      IncludeScopes = bool.TryParse(Environment.GetEnvironmentVariable("OTLP_LOGGING_INCLUDE_SCOPES"), out var includeScopes)
        ? includeScopes : configuration.GetValue("Logging:OpenTelemetry:IncludeScopes", false),

      ParseStateValues = bool.TryParse(Environment.GetEnvironmentVariable("OTLP_LOGGING_PARSE_STATE_VALUES"), out var parseStateValues)
        ? parseStateValues : configuration.GetValue("Logging:OpenTelemetry:ParseStateValues", false),

      SpanSamplingRatio = double.TryParse(Environment.GetEnvironmentVariable("OTLP_SPAN_SAMPLING_RATIO"), out var spanSamplingRatio)
        ? spanSamplingRatio : configuration.GetValue("OpenTelemetry:SamplingRatio", 1.0)
    };
  }
}