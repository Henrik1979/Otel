﻿using System.Net;

namespace WebAPI.Telemetry;

public interface IOtelMetrics
{
  void IncreaseIncomingCallCount(int count = 1, params KeyValuePair<string, object?>[] labels);
  Task<T> RecordMetricExecutingTime<T>(Func<Task<T>> workload, params KeyValuePair<string, object?>[] labels);

  KeyValuePair<string, object?>[] CreateLabels(HttpRequest request, HttpStatusCode responseCode, params KeyValuePair<string, object?>[] customLabels)
  {
    var keyValuePairs = new List<KeyValuePair<string, object?>>
    {
      new("http.route", request.Path.Value ?? string.Empty),
      new("http.request.method", request.Method),
      new("http.response.status_code", (int)responseCode)
    };

    keyValuePairs.AddRange(customLabels);
    return keyValuePairs.ToArray();
  }
}