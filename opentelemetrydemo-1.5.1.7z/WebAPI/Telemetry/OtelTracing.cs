﻿using System.Diagnostics;

namespace WebAPI.Telemetry;

public class OtelTracing
{
  public const string SourceName = "Web API";
  public const string Version = "0.1";

  public static readonly ActivitySource WebAPIActivitySource = new(SourceName);
}