﻿using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Net;

namespace WebAPI.Telemetry;

public class OtelMetrics : IOtelMetrics
{
  public const string MetricTimeHistogramName = "http_metric_server_duration_milliseconds_bucket";
  
  private Counter<int> IncomingCallCounter { get; }

  private Histogram<int> MetricTimeHistogram { get; }

  public OtelMetrics(string meterName)
  {
    var meter = new Meter(meterName);
    IncomingCallCounter = meter.CreateCounter<int>(name: "http.incoming.requests.total", unit: "requests", description: "http requests to the service");
    MetricTimeHistogram = meter.CreateHistogram<int>(MetricTimeHistogramName, "millis", "Time spend executing");
  }

  public void IncreaseIncomingCallCount(int count = 1, params KeyValuePair<string, object?>[] labels) => IncomingCallCounter.Add(count, labels);
  public async Task<T> RecordMetricExecutingTime<T>(Func<Task<T>> workload, params KeyValuePair<string, object?>[] labels)
  {
    var sw = Stopwatch.StartNew();
    try
    {
      return await workload();
    }
    finally
    {
      sw.Stop();
      MetricTimeHistogram.Record((int)sw.Elapsed.TotalMilliseconds, labels);
    }
  }
}