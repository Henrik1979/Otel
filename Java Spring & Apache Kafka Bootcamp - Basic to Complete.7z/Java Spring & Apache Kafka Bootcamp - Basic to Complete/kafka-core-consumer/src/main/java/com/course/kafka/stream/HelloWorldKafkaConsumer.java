package com.course.kafka.stream;

import com.course.TopicNames;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class HelloWorldKafkaConsumer {

    @KafkaListener(topics = TopicNames.SOURCE_TOPIC)
    public void consume(String message){
        log.info(message);
    }
}
