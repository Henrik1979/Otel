package com.course.kafka.stream;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.test.context.SpringBootTest;

@Slf4j
@SpringBootTest
class TestKafkaCoreConsumerApplication {

	private record User(String name, Long id){}

	//@Test
	void contextLoads() {
		// https://www.baeldung.com/slf4j-parameterized-logging

		var user = new User("hkrist", 1L);

		try {
			throw new RuntimeException("Logger test");
		} catch (RuntimeException ex) {

			log.error("App is running at {}", user);
			log.atError()
					.addKeyValue("user_info", user)
					.setMessage("Error processing given user")
					.setCause(ex)
					.addKeyValue("exception_class", ex.getClass().getSimpleName())
					.addKeyValue("error_message", ex.getMessage())
					.log();
		}
	}
}
