# README


## Commands

### Docker

Run sonar qube

````powershell
docker compose -f  .\sonarqube.yaml  up -d

docker compose -f  .\sonarqube.yaml  down 

# This will delete your monunts and your stored data => your project will be deleted
docker compose -f  .\sonarqube.yaml  down -v

````
http://localhost:9001/

Login: admin/admin

Install the "Dependency-Check" package from the marketplace:

![](./images/plugins.png)

### Check code quality

Note:
Create a new project and use the name and token as shown in the web UI

````powershell
mvn clean verify sonar:sonar "-Dsonar.projectKey=Test" "-Dsonar.projectName='Test'" "-Dsonar.host.url=http://localhost:9000" "-Dsonar.token=sqp_d817a3167e4ac57bec330b9ee9c73ace55aa2027"
````

### Security scanning

Check dependencies for vulnerabilities

````powershell
mvn clean verify -P owasp-dependency-check

# Update the dependencies
mvn org.owasp:dependency-check-maven:update-only -P owasp-dependency-check
````

### Check for updates

````powershell
# To display available updates for dependencies, use the following command - it also shows updates for the nested dependencies
mvn versions:display-dependency-updates

# For a few dependencies, we specify the version inside the properties section of pom.xml. 
# For such use cases, the display-properties-updates goal of the Versions plugin can be useful
mvn versions:display-property-updates

# To display available updates for plugins, use the following command:
mvn versions:display-plugin-updates

# To display available updates for parent POM, use the following command:
mvn versions:display-parent-updates
````

see how to update and do more checks [here](https://www.cloudhadoop.com/2018/08/understand-versions-maven-plugin-basics.html) and [here](https://bootcamptoprod.com/update-maven-dependencies/)

if something better is needed look into: [mvn versions:dependency-updates-report](https://www.mojohaus.org/versions/versions-maven-plugin/dependency-updates-report-mojo.html)
This report plugin not just shows more comprehensive details on updates but also has options to update to latest versions


### Create and compile single projects

Create new submodule
````powershell
mvn archetype:generate  "-DgroupId=com.course.kafka" "-DartifactId=kafka-simple-stream" "-DinteractiveMode=false"  "-Dversion=0.0.1-SNAPSHOT"
````

````powershell
mvn -pl .,kafka-core-consumer clean compile
````

````powershell
mvn -pl .,kafka-core-producer clean compile
````

````powershell
mvn -pl .,kafka-core-stream clean compile
````

````powershell
mvn -pl .,kafka-core clean compile
````

## Links

### MVN

* [Use the Latest Version of a Dependency in Maven](https://www.baeldung.com/maven-dependency-latest-version)
* [Jacoco (Java Code Coverage)](https://www.jacoco.org/jacoco/trunk/doc/maven.html)
* [mvn profiles](https://maven.apache.org/guides/introduction/introduction-to-profiles.html)
* [Jacoco configuration](https://natritmeyer.com/howto/reporting-aggregated-unit-and-integration-test-coverage-with-jacoco/)

### Spring

* [Spring for Apache Kafka](https://docs.spring.io/spring-kafka/reference/index.html)
* [The IoC Container](https://docs.spring.io/spring-framework/reference/core/beans.html)
* [Spring Boot](https://docs.spring.io/spring-boot/index.html)
* [Environment Abstraction](https://docs.spring.io/spring-framework/reference/core/beans/environment.html)
* [Environment Abstraction - Activating a Profile](https://docs.spring.io/spring-framework/reference/core/beans/environment.html#beans-definition-profiles-enable)


### Code Quality and Security for Java
https://github.com/SonarSource/sonar-java

* [SonarQube](https://docs.sonarsource.com/sonarqube/latest/analyzing-source-code/scanners/sonarscanner-for-maven/)
* [SonarQube in docker](https://medium.com/@denis.verkhovsky/sonarqube-with-docker-compose-complete-tutorial-2aaa8d0771d4)
* [Code Analysis with SonarQube](https://www.baeldung.com/sonar-qube)
* [Code Coverage with SonarQube](https://www.baeldung.com/sonarqube-jacoco-code-coverage)


### OWASP

[OWASP Dependency-Check](https://github.com/jeremylong/DependencyCheck?tab=readme-ov-file)
[Request free NVD API key](https://nvd.nist.gov/developers/request-an-api-key)

set NVD_API_KEY=720d276c-aa4e-450e-bf5b-9ba9d563a190
API Key: 720d276c-aa4e-450e-bf5b-9ba9d563a190
mvn org.owasp:dependency-check-maven:check "-DnvdApiKey=720d276c-aa4e-450e-bf5b-9ba9d563a190"

org.owasp:dependency-check Plugin Documentation

|Goal|Report| Description                                                                                                                                      |
|-|-|--------------------------------------------------------------------------------------------------------------------------------------------------|
|dependency-check:aggregate|Yes| Maven Plugin that checks project dependencies and the dependencies of all child modules to see if they have any known published vulnerabilities. |
|dependency-check:check|Yes| Maven Plugin that checks the project dependencies to see if they have any known published vulnerabilities.|
|dependency-check:help|No| Display help information on dependency-check-maven. Call mvn dependency-check:help -Ddetail=true -Dgoal=<goal-name> to display parameter details.                                                                                             |
|dependency-check:purge|Yes|Maven Plugin that purges the local copy of the NVD data.|
|dependency-check:update-only|Yes|Yes	Maven Plugin that updates the local cache of the NVD data from NIST.|

example usage:

````powershell
mvn org.owasp:dependency-check-maven:update-only -P owasp-dependency-check
````

### Cleanup cache

delete files

The cache is located here:
````
%USERPROFILE%/.m2/repository/org/owasp/dependency-check-data/9.0/cache
````

> [!WARNING]  
> it can take 45+ minutes to rebuild the cache! 
> Do this EARLY in the morning, it seems its less busy and faster at that point of time
