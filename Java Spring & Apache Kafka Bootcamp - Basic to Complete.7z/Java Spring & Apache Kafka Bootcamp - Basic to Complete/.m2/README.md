Copy the content of your .m2 directory here!!! that way mvn docker image doesn't have to download 1.6GB+ data 


your m2 is located [here](%userprofile%/.m2)