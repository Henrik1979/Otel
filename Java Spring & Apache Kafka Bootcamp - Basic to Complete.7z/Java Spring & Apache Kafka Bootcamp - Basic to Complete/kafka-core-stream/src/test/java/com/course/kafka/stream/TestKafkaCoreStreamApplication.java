package com.course.kafka.stream;

import com.course.TopicNames;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import javax.validation.constraints.AssertTrue;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@Slf4j
@SpringBootTest
public class TestKafkaCoreStreamApplication {

//    @Autowired
//    private TopicBean topicBean;

    @Test
    void contextLoads() {

        try {
            Thread.sleep(1_000);
        } catch (InterruptedException ex) {
            log.atError()
                    .setMessage("Error processing context")
                    .setCause(ex)
                    .addKeyValue("exception_class", ex.getClass().getSimpleName())
                    .addKeyValue("error_message", ex.getMessage())
                    .log();
        }
    }

   // @Test
   // void xxx(){
//        assertDoesNotThrow(() -> topicBean.createTopics());
//    }

}
