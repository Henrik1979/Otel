package com.course.kafka.stream;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Slf4j
@SpringBootTest
public class TestKafkaCoreStreamApplication {

    @Test
    void contextLoads() {

        try {
            Thread.sleep(120_000);

        } catch (InterruptedException ex) {
            log.atError()
                    .setMessage("Error processing context")
                    .setCause(ex)
                    .addKeyValue("exception_class", ex.getClass().getSimpleName())
                    .addKeyValue("error_message", ex.getMessage())
                    .log();
        }
    }
}
