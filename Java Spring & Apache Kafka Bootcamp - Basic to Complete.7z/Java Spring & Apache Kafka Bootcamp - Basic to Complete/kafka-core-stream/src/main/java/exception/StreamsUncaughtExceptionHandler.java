package exception;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StreamsUncaughtExceptionHandler implements org.apache.kafka.streams.errors.StreamsUncaughtExceptionHandler {

    @Override
    public StreamThreadExceptionResponse handle(Throwable exception) {


        /*
        Kafka StreamThreadExceptionResponse is an enum used for handling uncaught exceptions within Kafka Streams applications.
        It provides a way to define how your application reacts to unexpected errors during message processing. Here's a breakdown of the different values and their effects:

        1. REPLACE_THREAD:

        This is the recovery option. When an uncaught exception occurs in the current processing thread, Kafka Streams will:

        * Stop the current thread.
        * Start a new thread to handle messages from the same partitions the faulty thread was consuming.

        The overall processing continues with the same number of configured threads.
        This is useful for situations where the error might be specific to the current message or thread state. Replacing the thread allows processing to resume without impacting the entire application.


        2. SHUTDOWN_CLIENT:
        This is a more drastic approach. When an exception occurs:

        * The specific consumer client (the application instance) will be shut down.
        * Other consumer clients processing different partitions (potentially other application instances) will not be affected and continue processing.

        Use this option if the error indicates a severe issue with the consumer client itself, making it unfit to continue processing messages.


        3. SHUTDOWN_APPLICATION:
        This is the most severe option. When an exception occurs:
        * The entire Kafka Streams application will be shut down.
        * All consumer clients and processing threads will be terminated.

        Use this with caution as it completely halts message processing. This is ideal for critical errors that could potentially corrupt data or have a significant impact on the system.

        Choosing the Right Response
        Use REPLACE_THREAD for recoverable errors specific to a message or thread state.
        Use SHUTDOWN_CLIENT for errors that compromise the consumer client's functionality.
        Use SHUTDOWN_APPLICATION for critical errors with potential data corruption or system impact.
        */

        log.atError()
                .setMessage("Application threw an Exception")
                .setCause(exception)
                .log();

        return StreamThreadExceptionResponse.REPLACE_THREAD;
    }
}
