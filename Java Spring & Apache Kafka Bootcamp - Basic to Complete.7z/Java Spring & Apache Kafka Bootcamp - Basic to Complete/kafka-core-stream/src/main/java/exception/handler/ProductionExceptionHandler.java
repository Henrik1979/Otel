package exception.handler;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Map;

@Slf4j
public class ProductionExceptionHandler implements org.apache.kafka.streams.errors.ProductionExceptionHandler {
    @Override
    public ProductionExceptionHandlerResponse handle(
            final ProducerRecord<byte[], byte[]> record,
            final Exception exception) {

        log.atError()
                .setMessage("Failed to produce record")
                .addKeyValue("key", record.key())
                .addKeyValue("value", record.value())
                .addKeyValue("topic", record.topic())
                .addKeyValue("partition", record.partition())
                .setCause(exception).log();

        return ProductionExceptionHandlerResponse.FAIL;
    }

    @Override
    public void configure(final Map<String, ?> configs) {
        // ignore
    }
}