package com.course.kafka.stream;

import org.springframework.boot.autoconfigure.task.TaskExecutionAutoConfiguration;
import org.springframework.boot.web.embedded.tomcat.TomcatProtocolHandlerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.support.TaskExecutorAdapter;

import java.util.concurrent.Executors;


/**
 * TODO ALL THIS MIGHT NOT BE NEEDED!!!
 *
 * spring.threads.virtual.enabled = true
 *
 * This could be enough from  Spring Boot version 3.2 according to
 * <a href="https://medium.com/@aryak.deshpande0512/java-21-virtual-threads-in-spring-tomcat-a-practical-case-study-6d801f00b57d">Java 21 — Virtual threads in Spring & Tomcat (a practical case study)</a>
 * and <a href="https://www.danvega.dev/blog/virtual-threads-spring-boot">Virtual Threads in Spring Boot</a>
 *
 */
public class ThreadConfiguration {
    /**
     * According to the Spring documentation, this should enable virtual threads.
     * see <a href="https://spring.io/blog/2022/10/11/embracing-virtual-threads">Embracing Virtual Threads</a>
     *
     * # Virtual threads are designed to be lightweight, with low creation and teardown costs, minimal stack memory usage,
     * # and the ability to run in the thousands, even millions, without significant overhead.
     * # They are managed by the Java Virtual Machine (JVM) rather than the operating system, which allows for a much higher density of concurrent threads.
     * # See
     * # <a href="https://medium.com/hprog99/virtual-threads-in-java-unlocking-high-throughput-concurrency-55606100b6be">Virtual Threads in Java: Unlocking High-Throughput Concurrency</a>
     * # <a href="https://www.baeldung.com/spring-6-virtual-threads">Working with Virtual Threads in Spring 6</a>
     * # <a href="https://medium.com/@benweidig/looking-at-java-21-virtual-threads-0ddda4ac1be1">Looking at Java 21: Virtual Threads</a>
     * <a href="https://bootcamptoprod.com/spring-boot-virtual-threads/">Spring Boot Virtual Threads Explained: Easy Configuration & Examples</a>
     */
   /* @Bean(TaskExecutionAutoConfiguration.APPLICATION_TASK_EXECUTOR_BEAN_NAME)
    public AsyncTaskExecutor asyncTaskExecutor() {
        return new TaskExecutorAdapter(Executors.newVirtualThreadPerTaskExecutor());
    }*/

    /*@Bean
    public TomcatProtocolHandlerCustomizer<?> protocolHandlerCustomizer() {
        return c -> Executors.newVirtualThreadPerTaskExecutor();
    }*/
}
