package com.course.kafka.stream.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;


/**
 * OpenAPI
 *
 * Swagger endpoint:
 *  http://localhost/v3/api-docs
 *
 *  Swagger UI:
 * http://localhost/swagger-ui/index.html
 *
 * Example of how to set it uo
 * https://www.baeldung.com/spring-rest-openapi-documentation
 */

@RestController
@RequestMapping("/thread")
public class ThreadController {

    // https://javadoc.io/doc/io.swagger.core.v3/swagger-annotations/latest/index.html


    @Operation(
            summary = "Get a list with one element containing the current thread id, this is used to seeing if the implementation is using hardware or virtual threads",
            description = "Get a list with one element containing the current thread id, this is used to seeing if the implementation is using hardware or virtual threads",
            tags = {"threading"}
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "success",
                    content = {@Content(
                    mediaType = "application/json",
                    //array = @ArraySchema(schema = @Schema(implementation = String.class))
                    array = @ArraySchema(schema = @Schema(implementation = Dummy.class))

                    )}),
            @ApiResponse(responseCode = "400", description = "BAD REQUEST"),
            @ApiResponse(responseCode = "401", description = "UNAUTHORIZED"),
            @ApiResponse(responseCode = "403", description = "Forbidden"),
            @ApiResponse(responseCode = "404", description = "NOT_FOUND: Entity could not be found")}
    )
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getThreadType() throws JsonProcessingException {
        var data = new HashMap<String, Object>();
        data.put("ThreadId", Thread.currentThread().toString());
        String json = new ObjectMapper().writeValueAsString(data);

        return ResponseEntity.ok().body(json);
    }
}