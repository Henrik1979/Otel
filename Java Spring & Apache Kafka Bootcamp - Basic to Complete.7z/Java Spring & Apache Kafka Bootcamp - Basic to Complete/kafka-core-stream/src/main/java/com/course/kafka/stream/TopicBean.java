package com.course.kafka.stream;

import com.course.TopicNames;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.stereotype.Component;

@Component
public record TopicBean() {
    @Bean
    public KafkaAdmin.NewTopics createTopics() {
        return new KafkaAdmin.NewTopics(
                TopicBuilder
                        .name(TopicNames.SOURCE_TOPIC)
                        .replicas(1)
                        .partitions(2)
                        .build(),
                TopicBuilder
                        .name(TopicNames.SINK_TOPIC)
                        .replicas(1)
                        .partitions(2)
                        .build()
       );
    }
}
