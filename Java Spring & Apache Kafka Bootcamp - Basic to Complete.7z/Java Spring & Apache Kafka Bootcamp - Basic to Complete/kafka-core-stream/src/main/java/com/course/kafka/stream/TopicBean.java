package com.course.kafka.stream;

import com.course.TopicNames;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;

@Configuration
public class TopicBean {

    @Bean
    public KafkaAdmin.NewTopics createTopics() {
        return new KafkaAdmin.NewTopics(
                TopicBuilder
                        .name(TopicNames.SOURCE_TOPIC)
                        .partitions(2)
                        .replicas(1)
                        .build(),
                TopicBuilder
                        .name(TopicNames.SINK_TOPIC)
                        .partitions(2)
                        .replicas(1)
                        .build(),
                TopicBuilder
                        .name(TopicNames.MOVIE_QUOTE_SINK_TOPIC)
                        .partitions(2)
                        .replicas(1)
                        .build()  ,
                TopicBuilder
                        .name(TopicNames.PROTOBUF_MOVIE_SINK)
                        .partitions(2)
                        .replicas(1)
                        .build()
       );
    }
}
