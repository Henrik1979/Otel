package com.course.kafka.stream.util;

import com.google.protobuf.Message;
import io.confluent.kafka.streams.serdes.protobuf.KafkaProtobufSerde;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG;

@Component
public class ProtobufSerde {
    private static final String PROTOBUF_SERDE_FACTORY_BEAN_NAME = "protobufSerdeFactoryBean";

    private final String schemaRegistry;
    private final Map<Class<? extends Message>, KafkaProtobufSerde<? extends Message>> protobufSerde;

    @Autowired
    public ProtobufSerde(
            @Value("${schema.registry.url}") String schemaRegistry,
            @Qualifier(PROTOBUF_SERDE_FACTORY_BEAN_NAME) final Map<Class<? extends Message>, KafkaProtobufSerde<? extends Message>> protobufSerde) {
        this.schemaRegistry = schemaRegistry;
        this.protobufSerde = protobufSerde;
    }

    @SuppressWarnings("unused")
    @Bean(PROTOBUF_SERDE_FACTORY_BEAN_NAME)
    public Map<Class<? extends Message>, KafkaProtobufSerde<? extends Message>> protobufSerdeFactory() {
        return new HashMap<>();
    }

    @SuppressWarnings({"unchecked", "unused"})
    public <T extends Message> KafkaProtobufSerde<T> getKeySerde(final Class<T> keyClass) {
        return (KafkaProtobufSerde<T>) protobufSerde.computeIfAbsent(keyClass, _ -> createSerde(true));
    }

    @SuppressWarnings({"unchecked", "unused"})
    public <T extends Message> KafkaProtobufSerde<T> getValueSerde(final Class<T> valueClass) {
        return (KafkaProtobufSerde<T>) protobufSerde.computeIfAbsent(valueClass, _ -> createSerde(false));
    }

    private <T extends Message> KafkaProtobufSerde<T> createSerde(final boolean isKey) {
        var serde = new KafkaProtobufSerde<T>();
        Map<String, String> serdeConfig = new HashMap<>();
        serdeConfig.put(SCHEMA_REGISTRY_URL_CONFIG, schemaRegistry);
        serde.configure(serdeConfig, isKey);
        return serde;
    }
}
