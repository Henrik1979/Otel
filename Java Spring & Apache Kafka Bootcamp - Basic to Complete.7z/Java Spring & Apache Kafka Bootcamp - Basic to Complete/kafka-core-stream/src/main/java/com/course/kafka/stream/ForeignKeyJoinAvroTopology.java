//package com.course.kafka.stream;
//
//import com.course.TopicNames;
//import com.course.kafka.stream.util.AvroSerde;
//import io.confluent.developer.avro.*;
//import jakarta.annotation.PostConstruct;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.kafka.common.serialization.Serdes;
//import org.apache.kafka.common.utils.Bytes;
//import org.apache.kafka.streams.KeyValue;
//import org.apache.kafka.streams.StreamsBuilder;
//import org.apache.kafka.streams.kstream.*;
//import org.apache.kafka.streams.state.KeyValueStore;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Slf4j
//@Service
//public class ForeignKeyJoinAvroTopology {
//
//    private final StreamsBuilder builder;
//    private final AvroSerde avroSerde;
//
//    public ForeignKeyJoinAvroTopology(
//            @Autowired StreamsBuilder streamsBuilder,
//            @Autowired AvroSerde avroSerde) {
//        this.builder = streamsBuilder;
//        this.avroSerde = avroSerde;
//    }
//
//    @PostConstruct
//    public void buildAvroForeignKeyJoinTopology() {
//        // ignore the topic , just for triggering an event!
//        final var s = builder.stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()));
//
//        final var albumMaterialized = Materialized.<
//                        AlbumKey,
//                        Album,
//                        KeyValueStore<Bytes, byte[]>>as("Album-Avro-Store")
//                .withKeySerde(avroSerde.getKeySerde(AlbumKey.class))
//                .withValueSerde(avroSerde.getValueSerde(Album.class));
//
//
//        final var trackPurchasesMaterialized = Materialized.<
//                        TrackPurchaseKey,
//                        TrackPurchase,
//                        KeyValueStore<Bytes, byte[]>>as("TrackPurchases-Avro-Store")
//                .withKeySerde(avroSerde.getKeySerde(TrackPurchaseKey.class))
//                .withValueSerde(avroSerde.getValueSerde(TrackPurchase.class));
//
//        final var albumId = 1L;
//
//        var albumKTable = s.map((_, v) -> {
//                    var key = AlbumKey.newBuilder()
//                            .setId(albumId)
//                            .build();
//
//                    var value = Album.newBuilder()
//                            .setArtist("Artist")
//                            .setGenre(String.format("Genre-%s", v))
//                            .setId(albumId)
//                            .setTitle(String.format("Title-%s", v))
//                            .build();
//
//                    return new KeyValue<>(key, value);
//                })
//                .toTable(Named.as("Album-Avro-Table"), albumMaterialized);
//
//
//        var trackPurchasesKTable = s.map((_, v) -> {
//                    var key = TrackPurchaseKey.newBuilder()
//                            .setId(1L)
//                            .build();
//
//                    var value = TrackPurchase.newBuilder()
//                            .setId(99)
//                            .setPrice(15.99)
//                            .setAlbumId(albumId)
//                            .setSongTitle(String.format("SongTitle-%s", v))
//                            .build();
//
//                    return new KeyValue<>(key, value);
//                })
//                .toTable(Named.as("TrackPurchases-Avro-Table"), trackPurchasesMaterialized);
//
//        trackPurchasesKTable.join(
//                        albumKTable,
//                        (trackPurchase) -> AlbumKey.newBuilder().setId(trackPurchase.getAlbumId()).build(),
//                        (trackPurchase, album) -> MusicInterest.newBuilder()
//                                .setId(album.getId() + "-" + trackPurchase.getId())
//                                .setGenre(album.getGenre())
//                                .setArtist(album.getArtist())
//                                .build(),
//                        TableJoined.as("TrackPurchase-Album-Avro-Join"))
//                .toStream()
//                .to("MusicInterestTopicAvro",
//                        Produced.with(
//                                avroSerde.getKeySerde(TrackPurchaseKey.class),
//                                avroSerde.getValueSerde(MusicInterest.class)));
//    }
//}