package com.course.kafka.stream;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.MetricName;
import org.apache.kafka.common.metrics.MetricConfig;
import org.apache.kafka.common.metrics.Sensor;
import org.apache.kafka.common.metrics.stats.Avg;
import org.apache.kafka.common.metrics.stats.Max;
import org.apache.kafka.common.metrics.stats.Min;
import org.apache.kafka.streams.StreamsMetrics;
import org.apache.kafka.streams.processor.api.Processor;
import org.apache.kafka.streams.processor.api.ProcessorContext;
import org.apache.kafka.streams.processor.api.ProcessorSupplier;
import org.apache.kafka.streams.processor.api.Record;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Function;

@Slf4j
public class ProcessorJMX<KIn, VIn, KOut, VOut> implements ProcessorSupplier<KIn, VIn, KOut, VOut> {

    public static final String GROUP_NAME = "mainframe.latency.metrics";
    public static final String TAG_NAME = "processing.step";
    public static final String SENSOR_NAME = "mainframe.sensor";

    private final Function<StreamsMetrics, Sensor> sensorSupplier;
    private final BiConsumer<Sensor, Record<KIn, VIn>> recorder;

    public ProcessorJMX(Function<StreamsMetrics, Sensor> sensorSupplier, BiConsumer<Sensor, Record<KIn, VIn>> recorder) {
        this.sensorSupplier = sensorSupplier;
        this.recorder = recorder;
    }

    public ProcessorJMX(BiConsumer<Sensor, Record<KIn, VIn>> recorder, String tagValue) {
        final var level = Sensor.RecordingLevel.INFO;
        final var descriptionTemplate = "latency from mainframe to processing step within sampling window";

        this.sensorSupplier = (metrics) -> {

            try {
                var sensor = metrics.addSensor(SENSOR_NAME, level);

                Map<String, String> metricTags = new HashMap<>();
                metricTags.put(TAG_NAME, tagValue);

                MetricConfig metricConfig = new MetricConfig().recordLevel(level).timeWindow(1, TimeUnit.MINUTES);
                sensor.add(new MetricName("avg", GROUP_NAME, String.format("Average %s", descriptionTemplate), metricTags), new Avg(), metricConfig);
                sensor.add(new MetricName("max", GROUP_NAME, String.format("Maximum %s", descriptionTemplate), metricTags), new Max(), metricConfig);
                sensor.add(new MetricName("min", GROUP_NAME, String.format("Minimum %s", descriptionTemplate), metricTags), new Min(), metricConfig);

                return sensor;
            } catch (Exception e) {
                log.atError().setMessage("Failed to initialize Sensor").setCause(e).log();
                throw e;
            }
        };

        this.recorder = recorder;
    }

    @Override
    public Processor<KIn, VIn, KOut, VOut> get() {
        return new Processor<>() {

            private ProcessorContext<KOut, VOut> context;
            private Sensor sensor;

            @Override
            public void init(ProcessorContext<KOut, VOut> context) {
                this.context = context;

                try {
                    this.sensor = sensorSupplier.apply(context.metrics());
                } catch (Exception e){
                    log.atError().setMessage("Failed to setup sensor").setCause(e).log();
                    throw e;
                }
            }

            @SuppressWarnings("unchecked")
            @Override
            public void process(Record<KIn, VIn> record) {

                try {
                    recorder.accept(sensor, record);
                } catch (Exception e) {
                    log.atError().setMessage("Failed to record").setCause(e).log();
                }
                finally {
                    // Always forward message so we don't lose data downstream
                    context.forward((Record<KOut, VOut>) record);
                }
            }

            @Override
            public void close() {
                Processor.super.close();
            }
        };
    }
}