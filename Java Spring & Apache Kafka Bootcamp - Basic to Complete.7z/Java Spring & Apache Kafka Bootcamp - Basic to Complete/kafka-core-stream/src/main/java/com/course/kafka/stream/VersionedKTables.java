package com.course.kafka.stream;

import com.course.TopicNames;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.KeyValueBytesStoreSupplier;
import org.apache.kafka.streams.state.Stores;
import org.apache.kafka.streams.state.VersionedBytesStoreSupplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;


@Slf4j
@Component
public class VersionedKTables {
    private final StreamsBuilder builder;
    private final KafkaProducer<String, String> producer;

    public VersionedKTables(
            @Autowired StreamsBuilder streamsBuilder,
            @Autowired KafkaProducer<String, String> producer) {
        this.builder = streamsBuilder;
        this.producer = producer;
    }

    @PostConstruct
    public void run() {
        build();

        Instant now = Instant.now();

        writeStreamData(now);
        writeTableData(now);
    }

    @PreDestroy
    public void destroy() {
        producer.close();
    }

    private void build() {
       final VersionedBytesStoreSupplier versionedStoreSupplier = Stores.persistentVersionedKeyValueStore("my-versioned-ktable-store", Duration.ofMinutes(10));
     //   final KeyValueBytesStoreSupplier persistentStoreSupplier = Stores.persistentKeyValueStore("non-versioned-table");

        var materialized = Materialized.<String, String>as(versionedStoreSupplier)
                .withKeySerde(Serdes.String())
                .withValueSerde(Serdes.String());

        final KStream<String, String> streamInput = builder.stream(
                TopicNames.VERSIONED_INPUT_TOPIC,
                Consumed
                        .with(Serdes.String(), Serdes.String())
                        .withName("Stream-for-version-join")
        );

        final KTable<String, String> tableInput =
                builder.stream(TopicNames.VERSIONED_TABLE_INPUT_TOPIC,
                                Consumed
                                        .with(Serdes.String(), Serdes.String())
                                        .withName("Table-stream-for-version-join"))
                        .toTable(Named.as("My-stream-2-table"), materialized);


        // final KTable<String, String> tableInput = builder.table(TopicNames.VERSIONED_TABLE_INPUT_TOPIC, materialized);


        final ValueJoiner<String, String, String> valueJoiner = (val1, val2) -> String.format("%s %s", val1, val2);

        streamInput.join(
                        tableInput,
                        valueJoiner,
                        Joined.as("value-joiner"))
                .peek((key, value) -> System.out.println("Joined value: " + value), Named.as("my-stream-peekaboo"))
                .to(TopicNames.VERSIONED_OUTPUT_TOPIC,
                        Produced
                                .with(Serdes.String(), Serdes.String())
                                .withName("versioned-table-stream-joiner"));
    }


    private void writeStreamData(Instant now) {
        final int partition = 0;

        var produceRecords = Arrays.asList(
                new ProducerRecord<>(
                        TopicNames.VERSIONED_INPUT_TOPIC, partition,
                        now.minus(50, ChronoUnit.SECONDS).toEpochMilli(),
                        "one", "peanut butter and"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_INPUT_TOPIC, partition,
                        now.minus(40, ChronoUnit.SECONDS).toEpochMilli(),
                        "two", "ham and"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_INPUT_TOPIC, partition,
                        now.minus(30, ChronoUnit.SECONDS).toEpochMilli(),
                        "three", "cheese and"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_INPUT_TOPIC, partition,
                        now.minus(20, ChronoUnit.SECONDS).toEpochMilli(),
                        "four", "tea and"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_INPUT_TOPIC, partition,
                        now.minus(10, ChronoUnit.SECONDS).toEpochMilli(),
                        "five", "coffee with"),

                // Add late stream value that shouldn't be joined with old ktable values
                new ProducerRecord<>(
                        TopicNames.VERSIONED_INPUT_TOPIC, partition,
                        now.plus(10, ChronoUnit.SECONDS).toEpochMilli(),
                        "one", "bread, crackers, salad and"),

                // Add a very old one, there shouldn't be anything to join with
                new ProducerRecord<>(
                        TopicNames.VERSIONED_INPUT_TOPIC, partition,
                        now.minus(10, ChronoUnit.DAYS).toEpochMilli(),
                        "one", "old shoes and")
        );

        sendMessages(produceRecords);
    }

    private void sendMessages(List<ProducerRecord<String, String>> produceRecords) {
        produceRecords.forEach(msg -> {
            producer.send(msg, (metadata, exception) -> {
                if (exception != null) {

                    log.atError()
                            .setCause(exception)
                            .setMessage("Failed to send message")
                            .log();
                } else {
                    log.info("Produced record at offset {} to topic {}", metadata.offset(), metadata.topic());
                }
            });
        });
    }

    private void writeTableData(Instant now) {
        final int partition = 0;

        var produceRecords = Arrays.asList(
                new ProducerRecord<>(
                        TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition,
                        now.minus(50, ChronoUnit.SECONDS).toEpochMilli(),
                        "one", "jelly"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition,
                        now.minus(40, ChronoUnit.SECONDS).toEpochMilli(),
                        "two", "eggs"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition,
                        now.minus(30, ChronoUnit.SECONDS).toEpochMilli(),
                        "three", "crackers"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition,
                        now.minus(30, ChronoUnit.SECONDS).toEpochMilli(),
                        "four", "crumpets"),
                new ProducerRecord<>(
                        TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition,
                        now.minus(30, ChronoUnit.SECONDS).toEpochMilli(),
                        "five", "cream"),

                // Add late values that shouldn't be joined with the stream since the time doesn't match
                new ProducerRecord<>(TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition, now.toEpochMilli(), "one", "sardines"),
                new ProducerRecord<>(TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition, now.toEpochMilli(), "two", "an old tire"),
                new ProducerRecord<>(TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition, now.toEpochMilli(), "three", "fish eyes"),
                new ProducerRecord<>(TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition, now.toEpochMilli(), "four", "moldy bread"),
                new ProducerRecord<>(TopicNames.VERSIONED_TABLE_INPUT_TOPIC, partition, now.toEpochMilli(), "five", "lots of salt")
        );

        sendMessages(produceRecords);
    }
}
