package com.course.kafka.stream.util;

import com.google.common.collect.Maps;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import org.apache.avro.specific.SpecificRecord;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG;

@Component
public class AvroSerde {

    private static final String AVRO_SERDE_FACTORY_BEAN_NAME = "avroSerdeFactoryBean";

    public final String schemaRegistry;
    private final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> avroSerdes;

    @Autowired
    public AvroSerde(@Value("${schema.registry.url}") String schemaRegistry,
                     @Qualifier(AVRO_SERDE_FACTORY_BEAN_NAME) final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> avroSerdes) {
        this.schemaRegistry = schemaRegistry;
        this.avroSerdes = avroSerdes;
    }


    @SuppressWarnings({"unused"})
    @Bean(AVRO_SERDE_FACTORY_BEAN_NAME)
    public Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> valueAvroSerdeFactory() {
        return new HashMap<>();
    }


    @SuppressWarnings({"unchecked", "unused"})
    public <T extends SpecificRecord> SpecificAvroSerde<T> getKeySerde(final Class<T> keyClass) {
        return (SpecificAvroSerde<T>) avroSerdes.computeIfAbsent(keyClass, x -> createSerde(true));
    }

    @SuppressWarnings({"unchecked", "unused"})
    public <T extends SpecificRecord> SpecificAvroSerde<T> getValueSerde(final Class<T> valueClass) {
        return (SpecificAvroSerde<T>) avroSerdes.computeIfAbsent(valueClass, x -> createSerde(false));
    }

    private <T extends SpecificRecord> SpecificAvroSerde<T> createSerde(final boolean isKey) {
        SpecificAvroSerde<T> serde = new SpecificAvroSerde<>();
        Map<String, String> serdeConfig = Maps.newHashMap();
        serdeConfig.put(SCHEMA_REGISTRY_URL_CONFIG, schemaRegistry);
        serde.configure(serdeConfig, isKey);
        return serde;
    }

    @SuppressWarnings("unchecked")
    public <T> Serde<T> getPrimitiveAvroSerde(boolean isKey) {
        final KafkaAvroDeserializer deserializer = new KafkaAvroDeserializer();
        final KafkaAvroSerializer serializer = new KafkaAvroSerializer();
        final Map<String, String> config = new HashMap<>();
        config.put(SCHEMA_REGISTRY_URL_CONFIG,schemaRegistry);
        deserializer.configure(config, isKey);
        serializer.configure(config, isKey);
        return (Serde<T>) Serdes.serdeFrom(serializer, deserializer);
    }




//    private static final String KEY_SERDE_FACTORY_BEAN_NAME = "avroKeySerdeFactoryBean";
//    private static final String VALUE_SERDE_FACTORY_BEAN_NAME = "avroValueSerdeFactoryBean";
//
//    public final String schemaRegistry;
//
//    private final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> avroKeySerdes;
//    private final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> avroValueSerdes;
//
//    @Autowired
//    public AvroSerde(@Value("${schema.registry.url}") String schemaRegistry,
//                     @Qualifier(KEY_SERDE_FACTORY_BEAN_NAME) final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> avroKeySerdes,
//                     @Qualifier(VALUE_SERDE_FACTORY_BEAN_NAME) final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> avroValueSerdes) {
//        this.schemaRegistry = schemaRegistry;
//        this.avroKeySerdes = avroKeySerdes;
//        this.avroValueSerdes = avroValueSerdes;
//    }
//
//
//    @SuppressWarnings({"unused"})
//    @Bean(VALUE_SERDE_FACTORY_BEAN_NAME)
//    public Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> valueAvroSerdeFactory() {
//        return new HashMap<>();
//    }
//
//    @SuppressWarnings({"unused"})
//    @Bean(KEY_SERDE_FACTORY_BEAN_NAME)
//    public Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> keyAvroSerdeFactory() {
//        return new HashMap<>();
//    }
//
//    @SuppressWarnings({"unchecked", "unused"})
//    public <T extends SpecificRecord> SpecificAvroSerde<T> getKeySerde(final Class<T> keyClass) {
//        return (SpecificAvroSerde<T>) avroKeySerdes.computeIfAbsent(keyClass, _ -> createKeySerde());
//    }
//
//    @SuppressWarnings({"unchecked", "unused"})
//    public <T extends SpecificRecord> SpecificAvroSerde<T> getValueSerde(final Class<T> valueClass) {
//        return (SpecificAvroSerde<T>) avroValueSerdes.computeIfAbsent(valueClass, _ -> createValueSerde());
//    }
//
//    private <T extends SpecificRecord> SpecificAvroSerde<T> createKeySerde() {
//        return createSerde(true);
//    }
//
//    private <T extends SpecificRecord> SpecificAvroSerde<T> createValueSerde() {
//        return createSerde(false);
//    }
//
//    private <T extends SpecificRecord> SpecificAvroSerde<T> createSerde(final boolean isKey) {
//        SpecificAvroSerde<T> serde = new SpecificAvroSerde<>();
//        Map<String, String> serdeConfig = Maps.newHashMap();
//        serdeConfig.put(SCHEMA_REGISTRY_URL_CONFIG, schemaRegistry);
//        serde.configure(serdeConfig, isKey);
//        return serde;
//    }
}
