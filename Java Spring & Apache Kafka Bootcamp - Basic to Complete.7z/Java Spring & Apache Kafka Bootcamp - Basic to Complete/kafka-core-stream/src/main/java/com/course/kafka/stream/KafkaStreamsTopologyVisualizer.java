package com.course.kafka.stream;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;

@Order(Ordered.LOWEST_PRECEDENCE) // load last - we need the topology to be build first (seems like it doesn't work when PostConstruct)
@DependsOn({"protobufTopology", "foreignKeyJoinProtobufTopology"}) // force the topology to run first - order isn't enough
@Slf4j
@Configuration
public class KafkaStreamsTopologyVisualizer {

    private final StreamsBuilderFactoryBean streamsBuilderFactoryBean;

    @Autowired
    public KafkaStreamsTopologyVisualizer(StreamsBuilderFactoryBean streamsBuilderFactoryBean) {
        this.streamsBuilderFactoryBean = streamsBuilderFactoryBean;
    }

    @PostConstruct
    public void setupTopology() throws Exception {
        StreamsBuilder builder = streamsBuilderFactoryBean.getObject();
        if (builder == null) {
            return;
        }

        Topology topology = builder.build();
        log.info("Topology Description: {}", topology.describe().toString());
    }
}
