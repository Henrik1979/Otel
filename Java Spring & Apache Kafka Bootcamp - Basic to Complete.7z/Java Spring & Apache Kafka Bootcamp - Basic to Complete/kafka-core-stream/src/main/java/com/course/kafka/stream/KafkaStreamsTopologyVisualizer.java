package com.course.kafka.stream;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;

@Configuration
public class KafkaStreamsTopologyVisualizer {

    private final StreamsBuilderFactoryBean streamsBuilderFactoryBean;

    public KafkaStreamsTopologyVisualizer(@Autowired final StreamsBuilderFactoryBean streamsBuilderFactoryBean) {
        this.streamsBuilderFactoryBean = streamsBuilderFactoryBean;
    }

    @PostConstruct
    public void printTopology() {
       // streamsBuilderFactoryBean.ge
    }
}
