package com.course.kafka.stream;

import com.course.TopicNames;
import com.course.kafka.TestRecordOuterClass;
import com.course.kafka.stream.util.ProtobufSerde;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class ProtobufTopology {

    private final StreamsBuilder builder;
    private final ProtobufSerde protobufSerde;

    public ProtobufTopology(
            @Autowired StreamsBuilder streamsBuilder,
            @Autowired ProtobufSerde protobufSerde) {
        this.builder = streamsBuilder;
        this.protobufSerde = protobufSerde;
    }

    @PostConstruct
    public void run() {

        // ignore the topic , just for triggering an event!
        final var s = builder.stream(TopicNames.SOURCE_TOPIC,
                Consumed
                        .with(Serdes.String(), Serdes.String())
                        .withName(String.format("%s-%s-stream", TopicNames.SOURCE_TOPIC, ProtobufTopology.class.getSimpleName())));

        s.map((k, v) -> {
                    return new KeyValue<>(
                            k,
                            TestRecordOuterClass.TestRecord.newBuilder()
                                    //  .setBoolValue(true)
                                    //.setByteValue()
                                    // .setOther(TestRecordOuterClass.TestRecord.Other.newBuilder().setStr("other string value").build())
                                    //    .setEnum(TestRecordOuterClass.TestRecord.Enum.B)
                                    .setInt32Value(2)
                                    .setInt64Value(4)
                                    .setStringValue("String")
                                    .build());

                })
                .to("TestRecord_Sink", Produced.with(Serdes.String(), protobufSerde.getValueSerde(TestRecordOuterClass.TestRecord.class)));

        builder.stream("TestRecord_Sink", Consumed.with(Serdes.String(), protobufSerde.getValueSerde(TestRecordOuterClass.TestRecord.class)))
                .peek((k, v) -> {

                    log.atInfo().setMessage("--------------------------------------------->").log();
                });

    }
}