package com.course.kafka.stream;

import com.course.TopicNames;
import com.course.kafka.stream.util.ProtobufSerde;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Named;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import proto.model.MovieOuterClass;

import static com.course.TopicNames.PROTOBUF_MOVIE_SINK;
import static org.apache.kafka.common.serialization.Serdes.String;

@Slf4j
@Configuration
public class ProtobufTopology {

    private final StreamsBuilder builder;
    private final ProtobufSerde protobufSerde;

    public ProtobufTopology(@Autowired StreamsBuilder streamsBuilder, @Autowired ProtobufSerde protobufSerde) {
        this.builder = streamsBuilder;
        this.protobufSerde = protobufSerde;
    }

    @PostConstruct
    public void run() {

        final var movieProtoSerde = protobufSerde.getValueSerde(MovieOuterClass.Movie.class);
        // ignore the topic , just for triggering an event!
        final var s =
                builder.stream(
                        TopicNames.SOURCE_TOPIC,
                        Consumed
                                .with(String(), String())
                                .withName(String.format("%s-%s-stream", TopicNames.SOURCE_TOPIC, ProtobufTopology.class.getSimpleName())));

        s.map((k, v) ->
                new KeyValue<>(k, MovieOuterClass.Movie.newBuilder()
                        .setReview(3.5)
                        .setReleaseYear(1979)
                        .setTitle(String.format("Title: %s", v)).build()),

                Named.as(String.format("%s-source-to-movie-mapper", ProtobufTopology.class.getSimpleName())))
                .to(
                        PROTOBUF_MOVIE_SINK,
                        Produced
                                .with(String(), movieProtoSerde)
                                .withName(String.format("%s-sink-writer", ProtobufTopology.class.getSimpleName())));

        builder.stream(
                PROTOBUF_MOVIE_SINK,
                Consumed
                        .with(String(), movieProtoSerde)
                        .withName(String.format("%s-source-stream-reader", ProtobufTopology.class.getSimpleName())))
                .peek((k, v) -> log.atInfo().setMessage(String.format("Handling movie: %s", v.getTitle())).log()
                                , Named.as(String.format("%s-source-to-movie-mapper-peek", ProtobufTopology.class.getSimpleName())));
    }
}