package com.course.kafka.stream;

import exception.StreamsUncaughtExceptionHandler;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaStreamsDefaultConfiguration;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.config.StreamsBuilderFactoryBeanConfigurer;
import org.springframework.kafka.core.KafkaAdmin;

import java.util.HashMap;
import java.util.Map;

import static org.apache.kafka.streams.StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG;
import static org.apache.kafka.streams.StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG;

@Configuration
@Slf4j
public class StreamInit {

    private final KafkaProperties kafkaProperties;

    public StreamInit(@Autowired KafkaProperties kafkaProperties) {
        this.kafkaProperties = kafkaProperties;
    }

    @Bean
    public StreamsBuilderFactoryBeanConfigurer streamsBuilderFactoryBeanConfigurer() {
        return factoryBean -> factoryBean.setStreamsUncaughtExceptionHandler(new StreamsUncaughtExceptionHandler());
    }

    //TODO it seems like running locally the program works without kafkaAdmin/adminClient but in docker they act differently... investigate!
    @Bean
    public KafkaAdmin kafkaAdmin() {
        Map<String, Object> configs = new HashMap<>(kafkaProperties.buildAdminProperties(null));
        configs.putIfAbsent(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBootstrapServers());
        return new KafkaAdmin(configs);
    }

    //TODO it seems like running locally the program works without kafkaAdmin/adminClient but in docker they act differently... investigate!
    @Bean
    public AdminClient adminClient() {
        Map<String, Object> configs = new HashMap<>(kafkaProperties.buildAdminProperties(null));
        configs.putIfAbsent(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getBootstrapServers());
        return AdminClient.create(configs);
    }

    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    public KafkaStreamsConfiguration kStreamsConfigs(@Value("${schema.registry.url}") String schemaRegistry) {
        var kafkaStreamProperties = kafkaProperties.buildStreamsProperties(null);
        kafkaStreamProperties.put(DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        kafkaStreamProperties.put(DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());

        // when using schema registry remember to add url
        kafkaStreamProperties.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistry);

        // Spring specific - you can use a custom implementation instead where you have more control and configure it in property file
        //kafkaStreamProperties.put(RecoveringDeserializationExceptionHandler.KSTREAM_DESERIALIZATION_RECOVERER, recoverer());

        return new KafkaStreamsConfiguration(kafkaStreamProperties);
    }

    // Alternative to making a custom DeserializationExceptionHandler - spring boot specific
    /*private static ConsumerRecordRecoverer recoverer() {
        return (consumerRecord, e) -> {

            log.atError()
                    .setMessage("Exception caught during Deserialization")
                    .setCause(e)
                    .addKeyValue("topic", consumerRecord.topic())
                    .addKeyValue("partition", consumerRecord.partition())
                    .addKeyValue("offset", consumerRecord.offset())
                    .log();
        };
    }*/
}
