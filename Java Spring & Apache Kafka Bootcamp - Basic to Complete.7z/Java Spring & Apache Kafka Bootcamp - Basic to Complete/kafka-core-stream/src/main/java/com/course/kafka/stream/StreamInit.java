package com.course.kafka.stream;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.processor.WallclockTimestampExtractor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.annotation.KafkaStreamsDefaultConfiguration;
import org.springframework.kafka.config.KafkaStreamsConfiguration;

import java.util.Map;

import static org.apache.kafka.streams.StreamsConfig.*;


@Configuration
@EnableKafka
@EnableKafkaStreams
public class StreamInit {

    // https://docs.confluent.io/platform/current/streams/monitoring.html#built-in-metrics
    @Bean(name =
            KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    public KafkaStreamsConfiguration kStreamsConfigs() {
        return new KafkaStreamsConfiguration(Map.of(
                APPLICATION_ID_CONFIG, "testStreams",
                BOOTSTRAP_SERVERS_CONFIG, "localhost:19092",
                DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName(),
                DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName(),
                DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG, WallclockTimestampExtractor.class.getName()
        ));
    }
}



   // private final KafkaStreams streams;

   /* @Autowired
    private KafkaProperties properties;

    @Bean()
    AdminClient q(final @Autowired @NonNull KafkaProperties properties) {
        Map<String, Object> props = new HashMap<>(properties.getProperties());
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        return AdminClient.create(props);
    }


    @Bean()
    KafkaAdmin q1(final @Autowired @NonNull KafkaProperties properties) {
        Map<String, Object> props = new HashMap<>(properties.getProperties());
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        return new KafkaAdmin(props);
    }

  /*  @Bean
    public Topology topology(@Autowired StreamsBuilder builder) {

        KStream<String, String> stream = builder.stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()));
        KStream<String, String> transformedStream = stream.mapValues(value -> value.toUpperCase());
        transformedStream.to(TopicNames.SINK_TOPIC,
                Produced.with(Serdes.String(), Serdes.String()));
       return builder.build();
    }*/




   /* @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    KafkaStreamsConfiguration kStreamsConfig() {
        Map<String, Object> props = new HashMap<>(properties.getProperties());
        props.put(APPLICATION_ID_CONFIG, "streams-app");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        props.put(DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, LogAndFailExceptionHandler.class.getName());

        return new KafkaStreamsConfiguration(props);
    }
}

   /* public StreamInit(
            final @Autowired @NonNull Topology topology,
            final @Autowired @NonNull KafkaProperties properties ,       @Autowired Environment environment) {

      /*  Properties prop = new Properties();
        prop.putAll(properties.getProperties());
        prop.put(APPLICATION_ID_CONFIG, "my-stream");
        prop.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        prop.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        prop.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        prop.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        prop.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        prop.put("bootstrap.servers", "localhost:19092");
        prop.put(DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        prop.put(DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());


        //this.streams = new KafkaStreams(topology, prop);
    }

    @PostConstruct
    public void startStream() {
        this.streams.start();
    }

    @PreDestroy
    public void closeStream() {
        this.streams.close();
    }*/
//}