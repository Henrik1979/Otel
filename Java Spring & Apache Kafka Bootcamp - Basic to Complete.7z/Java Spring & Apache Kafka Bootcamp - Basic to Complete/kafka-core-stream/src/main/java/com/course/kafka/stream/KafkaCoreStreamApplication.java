package com.course.kafka.stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.EnableKafkaStreams;

// https://developer.confluent.io/courses/spring/process-messages-with-kafka-streams/?session_ref=https://developer.confluent.io/tutorials/filter-a-stream-of-events/kstreams.html
// https://developer.confluent.io/courses/spring/hands-on-process-messages-with-kafka-streams/?session_ref=https://developer.confluent.io/tutorials/filter-a-stream-of-events/kstreams.html

@EnableKafkaStreams
@SpringBootApplication
@ConfigurationPropertiesScan
@EnableKafka
public class KafkaCoreStreamApplication {
    public static void main(String[] args) {
        SpringApplication.run(KafkaCoreStreamApplication.class, args);
    }
}