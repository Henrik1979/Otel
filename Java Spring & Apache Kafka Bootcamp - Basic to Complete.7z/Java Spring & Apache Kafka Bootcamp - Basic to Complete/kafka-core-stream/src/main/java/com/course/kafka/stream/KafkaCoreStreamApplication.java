package com.course.kafka.stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafkaStreams;

@EnableKafkaStreams
@SpringBootApplication
public class KafkaCoreStreamApplication {
    public static void main(String[] args) {
        SpringApplication.run(KafkaCoreStreamApplication.class, args);
    }
}