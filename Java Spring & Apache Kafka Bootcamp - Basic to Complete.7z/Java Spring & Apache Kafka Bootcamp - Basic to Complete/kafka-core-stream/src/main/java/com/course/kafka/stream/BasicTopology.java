package com.course.kafka.stream;

import com.course.TopicNames;
import com.course.kafka.MovieQuote;
import com.course.kafka.MovieQuoteKey;
import com.course.kafka.MovieQuoteX.Quote;
import com.course.kafka.stream.util.AvroSerde;
import com.course.kafka.stream.util.ProtobufSerde;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.metrics.Sensor;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Named;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.processor.api.Record;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.function.BiConsumer;

@Slf4j
@Configuration
public class BasicTopology {

    @Bean
    public KStream<String, String> kStream(
            @Autowired StreamsBuilder builder,
            @Autowired AvroSerde avroSerde,
            @Autowired ProtobufSerde protobufSerde) {

        BiConsumer<Sensor, Record<String, String>> recorder = (sensor, _) -> sensor.record(System.currentTimeMillis(), System.currentTimeMillis());
        var stream = builder.stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()));

        stream.peek((key, value) ->
                log.atInfo()
                        .setMessage(String.format("----------- From %s -----------", TopicNames.SOURCE_TOPIC))
                        .addKeyValue("key", key)
                        .addKeyValue("value", value).log()
        );


        var streamProcessor = stream.process(new ProcessorJMX<String, String, String, String>(recorder, "source"), Named.as("ProcessorJMX-Processor-Name"));

        streamProcessor.peek((key, value) ->
                log.atInfo()
                        .setMessage(String.format("----------- From %s -----------", ProcessorJMX.class.getSimpleName()))
                        .addKeyValue("key", key)
                        .addKeyValue("value", value).log()
        );

        // Split the stream 1st continues as a string
        streamProcessor.to(TopicNames.SINK_TOPIC, Produced.with(Serdes.String(), Serdes.String()));

        // 2nd gets mapped to objects
        streamProcessor
                .map((key, value) ->
                        new KeyValue<>(
                                MovieQuoteKey.newBuilder().setQuoteKey(key).build(),
                                MovieQuote.newBuilder().setQuote(value).build()))

                .peek((key, value) ->
                        log.atInfo()
                                .setMessage("---------------------  From Map function --------------------- ")
                                .addKeyValue("key", key.getQuoteKey())
                                .addKeyValue("value", value.getQuote()).log()
                )

                .to(TopicNames.MOVIE_QUOTE_SINK_TOPIC,
                        Produced.with(
                                avroSerde.getKeySerde(MovieQuoteKey.class),
                                avroSerde.getValueSerde(MovieQuote.class)));

        streamProcessor
                .map((key, value) ->
                        new KeyValue<>(
                                key,
                                Quote.MyRecord.newBuilder()
                                        .setQuote(value)
                                        .setOther(Quote.OtherRecord.newBuilder().setText("From stream").build())
                                        .build()
                        )
                )
                .to(
                        TopicNames.MOVIE_QUOTE_PROTOBUF_SINK_TOPIC,
                        Produced.with(
                                Serdes.String(),
                                protobufSerde.getValueSerde(Quote.MyRecord.class)));

        return stream;
    }
}