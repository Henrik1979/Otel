package com.course.kafka.stream;

import com.course.TopicNames;
import org.apache.kafka.common.metrics.Sensor;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Named;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.processor.api.Record;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.function.BiConsumer;

@Configuration
public class BasicTopology {

    @Bean
    public KStream<String, String> kStream(StreamsBuilder builder) {

        //  Function<StreamsMetrics, Sensor> sensorSupplier = (streamsMetrics) -> streamsMetrics.addSensor("QWERTY", Sensor.RecordingLevel.INFO);
        BiConsumer<Sensor, Record<String, String>> recorder = (sensor, _) -> sensor.record(System.currentTimeMillis(), System.currentTimeMillis());

        var stream = builder.stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()));
        //stream.process(new ProcessorJMX<>(sensorSupplier, recorder), Named.as("ProcessorJMX-Processor-Name"));
        stream.process(new ProcessorJMX<>(recorder, "source"), Named.as("ProcessorJMX-Processor-Name"));
        stream.to(TopicNames.SINK_TOPIC, Produced.with(Serdes.String(), Serdes.String()));
        return stream;
    }
}
