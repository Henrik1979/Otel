//package com.course.kafka.stream;
//
//import com.course.TopicNames;
//import com.course.kafka.music.Music;
//import com.course.kafka.music.TrackPurchaseOuterClass;
//import com.course.kafka.stream.util.ProtobufSerde;
//import jakarta.annotation.PostConstruct;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.kafka.common.serialization.Serdes;
//import org.apache.kafka.common.utils.Bytes;
//import org.apache.kafka.streams.KeyValue;
//import org.apache.kafka.streams.StreamsBuilder;
//import org.apache.kafka.streams.kstream.Consumed;
//import org.apache.kafka.streams.kstream.Materialized;
//import org.apache.kafka.streams.kstream.Produced;
//import org.apache.kafka.streams.state.KeyValueStore;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Slf4j
//@Service
//public class ForeignKeyJoinProtobufTopology {
//
//    private final StreamsBuilder builder;
//    private final ProtobufSerde protobufSerde;
//
//    public ForeignKeyJoinProtobufTopology(
//            @Autowired StreamsBuilder streamsBuilder,
//            @Autowired ProtobufSerde protobufSerde) {
//        this.builder = streamsBuilder;
//        this.protobufSerde = protobufSerde;
//    }
//
//    @PostConstruct
//    public void buildProtobufSForeignKeyJoinTopology() {
//
//        // ignore the topic , just for triggering an event!
//        final var s = builder.stream(TopicNames.SOURCE_TOPIC,
//                Consumed
//                        .with(Serdes.String(), Serdes.String())
//                        .withName(String.format("%s-stream", TopicNames.SOURCE_TOPIC)));
//
//        final var albumMaterialized = Materialized.<
//                        Music.AlbumKey,
//                        Music.Album,
//                        KeyValueStore<Bytes, byte[]>>as("Album-Protobuf-Store")
//                .withKeySerde(protobufSerde.getKeySerde(Music.AlbumKey.class))
//                .withValueSerde(protobufSerde.getValueSerde(Music.Album.class));
//
//
//        final var trackPurchasesMaterialized = Materialized.<
//                        Music.TrackPurchaseKey,
//                        TrackPurchaseOuterClass.TrackPurchase,
//                        KeyValueStore<Bytes, byte[]>>as("TrackPurchases-Protobuf-Store")
//                .withKeySerde(protobufSerde.getKeySerde(Music.TrackPurchaseKey.class))
//                .withValueSerde(protobufSerde.getValueSerde(TrackPurchaseOuterClass.TrackPurchase.class));
//
//        final var albumId = 1L;
//
//        /*var albumKTable =*/
//      /*  s.map((_, v) -> {
//            var key = Music.AlbumKey.newBuilder()
//                    .setId(albumId)
//                    .build();
//
//            var value = Music.Album.newBuilder()
//                    .setArtist("Artist")
//                    .setGenre(String.format("Genre-%s", v))
//                    .setId(albumId)
//                    .setTitle(String.format("Title-%s", v))
//                    .build();
//
//            return new KeyValue<>(key, value);
//        }).to("Album_TEST", Produced.with(
//                protobufSerde.getKeySerde(Music.AlbumKey.class),
//                protobufSerde.getValueSerde(Music.Album.class)));
//
//        //   .toTable(Named.as("Album-Protobuf-Table"), albumMaterialized);*/
//
//
//        /* var trackPurchasesKTable = */
//
//
//        s.map((_, _) -> {
//                    var key = Music.TrackPurchaseKey.newBuilder()
//                            .setId(1L)
//                            .build();
//
//                    var value = TrackPurchaseOuterClass.TrackPurchase.newBuilder()
//                            .setId(99)
//                            .setPrice(15.123)
//                            .setAlbumId(albumId)
//                            .setSongTitle("song title")
//                            .build();
//
//          /*  try {
//
//                // Serialize to byte array
//                byte[] serialized = value.toByteArray();
//                // Deserialize from byte array
//                var deserialized = com.course.kafka.music.TrackPurchase.parseFrom(serialized);
//                // Verify that the deserialized object matches the original
//                log.info("-------------------------------------> {}", value.equals(deserialized) );
//
//            } catch (InvalidProtocolBufferException e) {
//                log.atError().setMessage("-------------------------------------> BOOOOM " ).setCause(e).log();
//                throw new RuntimeException(e);
//            }*/
//                    return new KeyValue<>(key, value);
//                })
//                .peek((k,v) -> {
//                    log.atInfo().setMessage("OUT -------------------------------------> " + v.getPrice()).log();
//                })
//                .to("qwerty",
//                        Produced.with(
//                                protobufSerde.getKeySerde(Music.TrackPurchaseKey.class),
//                                protobufSerde.getValueSerde(TrackPurchaseOuterClass.TrackPurchase.class)
//                        ));
//
//
//           /*  builder.stream("qwerty",
//                     Consumed
//                             .with(
//                                     protobufSerde.getKeySerde(Music.TrackPurchaseKey.class),
//                                     protobufSerde.getValueSerde(TrackPurchaseOuterClass.TrackPurchase.class) )
//                             .withName("my_qwerty"))
//                     .peek((_,v) -> {
//                         log.atInfo().setMessage("PEEK ------------------------------------> " + v.getPrice()).log();
//                     });*/
//
//
//         /*.to("Purchases_TEST", Produced.with(
//                protobufSerde.getKeySerde(Music.TrackPurchaseKey.class),
//                protobufSerde.getValueSerde(TrackPurchaseOuterClass.TrackPurchase.class)));*/
//
//
//        //    .toTable(Named.as("TrackPurchases-Protobuf-Table"), trackPurchasesMaterialized);
//
//      /*  trackPurchasesKTable.join(
//                        albumKTable,
//                        (trackPurchase) -> com.course.kafka.music.AlbumKey.newBuilder().setId(trackPurchase.getAlbumId()).build(),
//                        (trackPurchase, album) -> com.course.kafka.music.MusicInterest.newBuilder()
//                                .setId(album.getId() + "-" + trackPurchase.getId())
//                                .setGenre(album.getGenre())
//                                .setArtist(album.getArtist())
//                                .build(),
//                        TableJoined.as("TrackPurchase-Album-Protobuf-Join"))
//                .toStream()
//                .to("MusicInterestTopicProtobuf",
//                        Produced.with(
//                                protobufSerde.getKeySerde(com.course.kafka.music.TrackPurchaseKey.class),
//                                protobufSerde.getValueSerde(com.course.kafka.music.MusicInterest.class)));*/
//    }
//}