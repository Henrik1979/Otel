package com.course.kafka.stream;

import com.course.TopicNames;
import com.course.kafka.stream.util.ProtobufSerde;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.KeyValueStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ForeignKeyJoinProtobufTopology {
    private final StreamsBuilder builder;
    private final ProtobufSerde protobufSerde;

    public ForeignKeyJoinProtobufTopology(
            @Autowired StreamsBuilder streamsBuilder,
            @Autowired ProtobufSerde protobufSerde) {
        this.builder = streamsBuilder;
        this.protobufSerde = protobufSerde;
    }

    @PostConstruct
    public void buildProtobufSForeignKeyJoinTopology() {

        // ignore the topic , just for triggering an event!
        final var s = builder.stream(TopicNames.SOURCE_TOPIC,
                Consumed
                        .with(Serdes.String(), Serdes.String())
                        .withName(String.format("%s-stream", TopicNames.SOURCE_TOPIC)));

        final var albumMaterialized = Materialized.<
                        com.course.kafka.music.AlbumKey,
                        com.course.kafka.music.Album,
                        KeyValueStore<Bytes, byte[]>>as("Album-Protobuf-Store")
                .withKeySerde(protobufSerde.getKeySerde(com.course.kafka.music.AlbumKey.class))
                .withValueSerde(protobufSerde.getValueSerde(com.course.kafka.music.Album.class));


        final var trackPurchasesMaterialized = Materialized.<
                        com.course.kafka.music.TrackPurchaseKey,
                        com.course.kafka.music.TrackPurchase,
                        KeyValueStore<Bytes, byte[]>>as("TrackPurchases-Protobuf-Store")
                .withKeySerde(protobufSerde.getKeySerde(com.course.kafka.music.TrackPurchaseKey.class))
                .withValueSerde(protobufSerde.getValueSerde(com.course.kafka.music.TrackPurchase.class));

        final var albumId = 1L;

        var albumKTable =
                s.map((k, v) -> {
                            var key = com.course.kafka.music.AlbumKey.newBuilder()
                                    .setId(albumId)
                                    .build();

                            var value = com.course.kafka.music.Album.newBuilder()
                                    .setArtist("Artist")
                                    .setGenre(String.format("Genre-%s", v))
                                    .setId(albumId)
                                    .setTitle(String.format("Title-%s", v))
                                    .build();

                            return new KeyValue<>(key, value);
                        }, Named.as(String.format("%s-source-to-album-mapper", ForeignKeyJoinProtobufTopology.class.getSimpleName())))
                        .toTable(Named.as("Album-Protobuf-Table"), albumMaterialized);

        var trackPurchasesKTable =
                s.map((k, v) -> {
                            var key = com.course.kafka.music.TrackPurchaseKey.newBuilder()
                                    .setId(1L)
                                    .build();

                            var value = com.course.kafka.music.TrackPurchase.newBuilder()
                                    .setId(99)
                                    .setPrice(15.123)
                                    .setAlbumId(albumId)
                                    .setSongTitle("song title")
                                    .build();
                            return new KeyValue<>(key, value);
                        }, Named.as(String.format("%s-source-to-track-purchase-mapper", ForeignKeyJoinProtobufTopology.class.getSimpleName())))
                        .toTable(Named.as("TrackPurchases-Protobuf-Table"), trackPurchasesMaterialized);

        trackPurchasesKTable.join(
                        albumKTable,
                        (trackPurchase) ->
                                com.course.kafka.music.AlbumKey.newBuilder()
                                        .setId(trackPurchase.getAlbumId())
                                        .build(),

                        (trackPurchase, album) -> com.course.kafka.music.MusicInterest.newBuilder()
                                .setId(album.getId() + "-" + trackPurchase.getId())
                                .setGenre(album.getGenre())
                                .setArtist(album.getArtist())
                                .build(),

                        TableJoined.as("TrackPurchase-Album-Protobuf-Join"))
                .toStream(Named.as("TrackPurchase-Album-Protobuf-Join-Stream"))
                .to("MusicInterestTopicProtobuf",
                        Produced
                                .with(
                                        protobufSerde.getKeySerde(com.course.kafka.music.TrackPurchaseKey.class),
                                        protobufSerde.getValueSerde(com.course.kafka.music.MusicInterest.class))
                                .withName(String.format("%s-sink-writer", ForeignKeyJoinProtobufTopology.class.getSimpleName())));
    }
}