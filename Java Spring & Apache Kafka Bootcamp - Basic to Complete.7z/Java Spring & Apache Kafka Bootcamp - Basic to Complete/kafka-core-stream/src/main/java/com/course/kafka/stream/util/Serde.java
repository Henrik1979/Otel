package com.course.kafka.stream.util;

import com.google.common.collect.Maps;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroSerde;
import org.apache.avro.specific.SpecificRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

import static io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG;

@Service
public class Serde {
    private static final String KEY_SERDE_FACTORY_BEAN_NAME = "keySerdeFactoryBean";
    private static final String VALUE_SERDE_FACTORY_BEAN_NAME = "valueSerdeFactoryBean";

    public final String schemaRegistry;

    private final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> keySerdes;
    private final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> valueSerdes;

    @Autowired
    public Serde(@Value("${schema.registry.url}") String schemaRegistry,
                 @Qualifier(KEY_SERDE_FACTORY_BEAN_NAME) final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> keySerdes,
                 @Qualifier(VALUE_SERDE_FACTORY_BEAN_NAME) final Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> valueSerdes) {
        this.schemaRegistry = schemaRegistry;
        this.keySerdes = keySerdes;
        this.valueSerdes = valueSerdes;
    }
    @SuppressWarnings({"unused"})
    @Bean(VALUE_SERDE_FACTORY_BEAN_NAME)
    public Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> valueSerdeFactory() {
        return new HashMap<>();
    }

    @SuppressWarnings({"unused"})
    @Bean(KEY_SERDE_FACTORY_BEAN_NAME)
    public Map<Class<? extends SpecificRecord>, SpecificAvroSerde<? extends SpecificRecord>> keySerdeFactory() {
        return new HashMap<>();
    }

    @SuppressWarnings({"unchecked","unused"})
    public <T extends SpecificRecord> SpecificAvroSerde<T> getKeySerde(final Class<T> keyClass ) {
        return (SpecificAvroSerde<T>) keySerdes.computeIfAbsent(keyClass, _ -> createKeySerde());
    }

    @SuppressWarnings({"unchecked", "unused"})
    public <T extends SpecificRecord> SpecificAvroSerde<T> getValueSerde(final Class<T> valueClass) {
        return (SpecificAvroSerde<T>) valueSerdes.computeIfAbsent(valueClass, _ -> createValueSerde());
    }

    private <T extends SpecificRecord> SpecificAvroSerde<T> createKeySerde() {
        return createSerde(true);
    }

    private  <T extends SpecificRecord> SpecificAvroSerde<T> createValueSerde() {
        return createSerde(false);
    }

    private  <T extends SpecificRecord> SpecificAvroSerde<T> createSerde(final boolean isKey) {
        SpecificAvroSerde<T> serde = new SpecificAvroSerde<>();
        Map<String, String> serdeConfig = Maps.newHashMap();
        serdeConfig.put(SCHEMA_REGISTRY_URL_CONFIG, schemaRegistry);
        serde.configure(serdeConfig, isKey);
        return serde;
    }
}
