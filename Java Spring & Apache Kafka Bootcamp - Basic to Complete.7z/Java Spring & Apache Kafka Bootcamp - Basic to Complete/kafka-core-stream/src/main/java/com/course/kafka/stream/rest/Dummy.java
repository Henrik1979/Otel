package com.course.kafka.stream.rest;

import java.time.Instant;

public record Dummy(String name, Instant number) {
}
