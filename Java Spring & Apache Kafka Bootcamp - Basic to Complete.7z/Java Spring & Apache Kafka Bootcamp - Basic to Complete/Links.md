    // https://github.com/open-telemetry/opentelemetry-collector-contrib/tree/main/receiver/jmxreceiver
    // https://observiq.com/blog/how-to-monitor-jvm-with-opentelemetry
    // https://opentelemetry.io/docs/instrumentation/java/manual/#initialize-the-sdk

    // https://opentelemetry.io/docs/languages/java/instrumentation/

// https://github.com/open-telemetry/opentelemetry-java-instrumentation/tree/main/instrumentation/micrometer/micrometer-1.5/library
// https://github.com/open-telemetry/opentelemetry-java-examples/tree/main/micrometer-shim
// https://docs.confluent.io/platform/current/streams/monitoring.html#built-in-metrics



    // https://howtodoinjava.com/spring-core/spring-bean-life-cycle/
    /*
     * First, the container calls the bean constructor (the default constructor or the one annotated @Inject), to obtain an instance of the bean.
     * Next, the container initializes the values of all injected fields of the bean.
     * Next, the container calls all initializer methods of bean (the call order is not portable, don’t rely on it).
     * Finally, the @PostConstruct method, if any, is called.
     */
    @PostConstruct
    public void todo() {
    }

    @Bean
    public Topology topology(@Autowired StreamsBuilderFactoryBean factoryBean, @Autowired Environment env) throws Exception {
        Topology topology = factoryBean.getObject().build();

        return factoryBean.getObject().build();
    }