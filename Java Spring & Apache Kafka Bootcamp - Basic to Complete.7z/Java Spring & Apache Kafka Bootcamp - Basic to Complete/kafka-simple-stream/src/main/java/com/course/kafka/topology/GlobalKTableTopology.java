package com.course.kafka.topology;

import com.course.TopicNames;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.KeyValueStore;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class GlobalKTableTopology {

    //@Bean
    public Topology createTopology() {
        StreamsBuilder builder = new StreamsBuilder();

        // name will be: "stream application id" - "store name" - "changelog"
        var materialized = Materialized.<String, String, KeyValueStore<Bytes, byte[]>>as(String.format("%s-GlobalKTable-Store", TopicNames.SOURCE_TOPIC))
                .withKeySerde(Serdes.String())
                .withValueSerde(Serdes.String());


        // Since we can only register with a topic once - we'll make a stream nad write to 2 different topics that the
        // GlobalKStream can consume

        KStream<String, String> stream = builder.stream(
                TopicNames.SOURCE_TOPIC,
                Consumed.with(Serdes.String(), Serdes.String()));

        final var topic1 = "output-topic-1";
        final var topic2 = "output-topic-2";

        stream.to(topic1);
        stream.to(topic2);

        // GlobalKTable:
        // 1) In memory
        // 2) Readonly!  (can't even produce!)
        // 3) Quick access - but big dataset can course bottleneck and memory consumption issues
        // 4) Has no operations  - is used for joins
        GlobalKTable<String, String> materializedGlobalKTable = builder.globalTable(
                topic1,
                Consumed.with(Serdes.String(), Serdes.String()),
                materialized);


        // Create another GlobalKTable without materializing it
        GlobalKTable<String, String> nonMaterializedGlobalKtable = builder.globalTable(
                topic2,
                Consumed.with(Serdes.String(), Serdes.String()));

        return builder.build();
    }
}
