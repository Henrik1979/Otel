package com.course.kafka.telemetry;

import com.course.kafka.App;
import io.micrometer.core.instrument.MeterRegistry;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.exporter.prometheus.PrometheusHttpServer;
import io.opentelemetry.instrumentation.micrometer.v1_5.OpenTelemetryMeterRegistry;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.semconv.ServiceAttributes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


// For more information see:
// https://github.com/open-telemetry/opentelemetry-java-instrumentation/tree/main/instrumentation/micrometer/micrometer-1.5/library
// https://github.com/open-telemetry/opentelemetry-java-instrumentation
@Configuration
public class OpenTelemetryBean {

    private static final String RESOURCE_BEAN_NAME = "RESOURCE_BEAN";

    @Bean
    public MeterRegistry meterRegistry(OpenTelemetry openTelemetry) {
        return  OpenTelemetryMeterRegistry.builder(openTelemetry)
                // Simulate behavior of micrometer's PrometheusMeterRegistry
                .setPrometheusMode(true)
                .build();
    }


    @Bean
    public PrometheusHttpServer prometheusHttpServerBuilder() {
        //http://localhost:8989/metrics
        return PrometheusHttpServer.builder()
                .setHost("localhost")
                .setPort(8989).build();
    }

    @Bean
    public SdkMeterProvider meterSdkBuilder(
            @Autowired PrometheusHttpServer prometheusServer,
            @Qualifier(RESOURCE_BEAN_NAME) Resource resource) {
        return SdkMeterProvider.builder()
                .registerMetricReader(prometheusServer)
                .setResource(resource)
                .build();
    }

    @Bean
    public OpenTelemetry openTelemetry(@Autowired SdkMeterProvider sdkMeterProvider) {
        return OpenTelemetrySdk.builder()
                .setMeterProvider(sdkMeterProvider)
                .build();
    }

    @Bean(RESOURCE_BEAN_NAME)
    public Resource resourceBuilder() {
        return  Resource.getDefault()
                .toBuilder()
                .put( ServiceAttributes.SERVICE_NAME, App.class.getSimpleName())
                .put(ServiceAttributes.SERVICE_VERSION, "1.0.0").build();
    }
}
