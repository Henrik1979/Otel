package com.course.kafka.streamint;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.NonNull;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.stereotype.Component;

import java.util.Properties;

import static org.apache.kafka.streams.StreamsConfig.*;


@Component
public class StreamInit {

    private final KafkaStreams streams;

    public StreamInit(
            final @Autowired @NonNull Topology topology,
            final @Autowired @NonNull KafkaProperties kafkaProperties) {

        Properties prop = new Properties();
        prop.putAll(kafkaProperties.getProperties());

        prop.put(APPLICATION_ID_CONFIG, "my-stream");
        prop.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092");
        prop.put(DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        prop.put(DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        this.streams = new KafkaStreams(topology, prop);
    }

    @PostConstruct
    public void startStream() {

        // This deletes the state store , DON'T do this in production with lots of data
        this.streams.cleanUp();
        this.streams.start();
    }

    @PreDestroy
    public void closeStream() {
        this.streams.close();
    }
}