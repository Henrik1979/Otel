package com.course.kafka.processor;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.processor.api.Processor;
import org.apache.kafka.streams.processor.api.ProcessorContext;
import org.apache.kafka.streams.processor.api.ProcessorSupplier;
import org.apache.kafka.streams.processor.api.Record;

@Slf4j
public class SimpleProcessor implements  ProcessorSupplier<String, String, String, String> {

    @Override
    public Processor<String, String, String, String> get() {
        return new Processor<String, String, String, String>() {

            private ProcessorContext<String, String> context;

            @Override
            public void init(ProcessorContext<String, String> context) {
                this.context = context;
            }

            @Override
            public void process(Record<String, String> record) {

                log.info(SimpleProcessor.class.getName() + " HANDLE MESSAGE");

                this.context.forward(
                        new Record<String, String>(
                                record.key(),
                                String.format("%s:%s:%s",
                                        SimpleProcessor.class.getSimpleName(),
                                        this.context.recordMetadata().get().topic(),
                                        record.value()),
                                System. currentTimeMillis()
                        ));

            }

            @Override
            public void close() {
                Processor.super.close();
            }
        };
    }
}
