package com.course.kafka.topology;

import com.course.TopicNames;
import com.course.kafka.telemetry.Meter;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;

@Component
public class KStreamTopologyWithTelemetry {

    //@Bean
    public Topology createTopology(@Autowired Meter meter) throws NoSuchAlgorithmException, NoSuchProviderException {
        StreamsBuilder builder = new StreamsBuilder();

        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");

        var stream = builder.stream(
                TopicNames.SOURCE_TOPIC,
                Consumed.with(Serdes.String(), Serdes.String()));

        stream.mapValues(v -> {
            //  todo: cals time from timestamp in value
            meter.recordProcessingTime(
                    secureRandom.nextLong(1001),
                    "qwerty-operation");
            return v;
        }).to(TopicNames.SINK_TOPIC, Produced.with(Serdes.String(), Serdes.String()));

        return builder.build();
    }
}