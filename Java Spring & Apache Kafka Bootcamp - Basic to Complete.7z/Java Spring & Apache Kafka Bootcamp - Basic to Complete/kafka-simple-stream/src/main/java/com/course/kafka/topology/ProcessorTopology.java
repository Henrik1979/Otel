package com.course.kafka.topology;

import com.course.TopicNames;
import com.course.kafka.processor.ProcessorJMX;
import com.course.kafka.processor.SimpleProcessor;
import com.course.kafka.processor.SimpleProcessorWithStateStore;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.metrics.Sensor;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsMetrics;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Named;
import org.apache.kafka.streams.processor.api.Record;
import org.apache.kafka.streams.state.Stores;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.function.BiConsumer;
import java.util.function.Function;

@Slf4j
@Component
public class ProcessorTopology {

    //  @Bean
    public Topology createTopologyForFullProcessorAPI() {
        Topology topology = new Topology();

        final var sourceName = "SourceName";
        final var sinkName = "SinkName";
        final var processorName = "my-awesome-processor";

        return topology
                .addSource(sourceName, TopicNames.SOURCE_TOPIC)
                .addProcessor(processorName, new SimpleProcessor(), sourceName)
                .addSink(sinkName, TopicNames.SINK_TOPIC, processorName);
    }

    //@Bean
    public Topology createTopologyForDSL() {
        StreamsBuilder builder = new StreamsBuilder();

        builder
                .stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()))
                .process(new SimpleProcessor(), Named.as("Simple-Processor-Name"))
                .to(TopicNames.SINK_TOPIC);
        return builder.build();
    }


    // @Bean
    public Topology createTopologyForDSLWithStateStore() {
        StreamsBuilder builder = new StreamsBuilder();

        final var stateStoreName = "my-state-store";
        var keySerde = Serdes.String();
        var valueSerde = Serdes.String();

        var stateStoreBuilder = Stores
                .keyValueStoreBuilder(Stores.persistentKeyValueStore(stateStoreName), keySerde, valueSerde)
                .withCachingEnabled();

        var s = builder
                .addStateStore(stateStoreBuilder)
                .stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()));

        // We can't use Split, it's first predicate served !
        s
                .process(new SimpleProcessorWithStateStore(), Named.as("Simple-Processor-With-State-Store-Name"), stateStoreName)
                .peek((k, v) -> {
                    log.atInfo()
                            .setMessage("SimpleProcessorWithStateStore peek. key = {}, value = {}")
                            .addArgument(k)
                            .addArgument(v)
                            .log();
                }, Named.as("SimpleProcessorWithStateStore-Peekaboo"))
                .to(TopicNames.SINK_TOPIC);

        s
                .process(new SimpleProcessor(), Named.as("Simple-Processor-Name"))
                .peek((k, v) -> {
                    log.atInfo()
                            .setMessage("SimpleProcessor peek. key = {}, value = {}")
                            .addArgument(k)
                            .addArgument(v)
                            .log();
                }, Named.as("SimpleProcessor-Peekaboo"))
                .to(TopicNames.SINK_TOPIC);

        var topology = builder.build();

        // https://zz85.github.io/kafka-streams-viz/
        var t = topology.describe().toString();


        return topology;
    }

  /*  @Bean
    public Topology createTopologyForDSLWithStreamMetrics() {
        StreamsBuilder builder = new StreamsBuilder();

        Function<StreamsMetrics, Sensor> sensorSupplier = (streamsMetrics) -> streamsMetrics.addSensor("my-qwerty-sensor", Sensor.RecordingLevel.INFO);
        BiConsumer<Sensor, Record<String, String>> recorder = (sensor, _) -> sensor.record(1, System.currentTimeMillis());

        builder
                .stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()))
                .process(new ProcessorJMX<>(sensorSupplier, recorder), Named.as("ProcessorJMX-Processor-Name"))
                .to(TopicNames.SINK_TOPIC);

        return builder.build();
    }*/
}
