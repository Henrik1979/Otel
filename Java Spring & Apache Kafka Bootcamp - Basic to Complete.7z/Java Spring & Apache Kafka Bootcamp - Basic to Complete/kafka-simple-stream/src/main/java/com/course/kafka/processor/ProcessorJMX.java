package com.course.kafka.processor;

import org.apache.kafka.common.metrics.Sensor;
import org.apache.kafka.streams.StreamsMetrics;
import org.apache.kafka.streams.processor.api.Processor;
import org.apache.kafka.streams.processor.api.ProcessorContext;
import org.apache.kafka.streams.processor.api.ProcessorSupplier;
import org.apache.kafka.streams.processor.api.Record;

import java.util.function.BiConsumer;
import java.util.function.Function;

// https://docs.confluent.io/platform/current/streams/monitoring.html#built-in-metrics
public class ProcessorJMX<KIn, VIn, KOut, VOut> implements ProcessorSupplier<KIn, VIn, KOut, VOut> {

    private final Function<StreamsMetrics, Sensor> sensorSupplier;
    private final BiConsumer<Sensor, Record<KIn, VIn>> recorder;

    public ProcessorJMX(
            Function<StreamsMetrics, Sensor> sensorSupplier,
            BiConsumer<Sensor, Record<KIn, VIn>> recorder) {
        this.sensorSupplier = sensorSupplier;
        this.recorder = recorder;
    }

    @Override
    public Processor<KIn, VIn, KOut, VOut> get() {
        return new Processor<>() {

            private ProcessorContext<KOut, VOut> context;
            private Sensor sensor;


            @SuppressWarnings("unchecked")
            @Override
            public void process(Record<KIn, VIn> record) {
                recorder.accept(sensor, record);
                context.forward((Record<KOut, VOut>) record);
            }

            @Override
            public void init(ProcessorContext<KOut, VOut> context) {
                this.context = context;
                sensor = sensorSupplier.apply(context.metrics());
            }

            @Override
            public void close() {
                Processor.super.close();
            }
        };
    }
}

