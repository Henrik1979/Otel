package com.course.kafka.utils;

import com.google.gson.Gson;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serializer;

import java.nio.charset.StandardCharsets;

public class KafkaSerdesUtils {

    public static <T> Serde<T> getSerdes(Class<T> type, Gson gson) {
        final Serializer<T> serializer = (_, data) -> {
            if (data == null) return null;
            return gson.toJson(data).getBytes(StandardCharsets.UTF_8);
        };

        final Deserializer<T> deserializer = (_, data) -> {
            if (data == null || data.length == 0) return null;
            return gson.fromJson(new String(data, StandardCharsets.UTF_8), type);
        };

        return Serdes.serdeFrom(serializer, deserializer);
    }
}
