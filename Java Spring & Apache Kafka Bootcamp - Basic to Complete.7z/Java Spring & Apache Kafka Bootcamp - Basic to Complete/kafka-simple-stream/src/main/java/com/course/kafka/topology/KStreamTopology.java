package com.course.kafka.topology;

import com.course.TopicNames;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.stereotype.Component;

@Component
public class KStreamTopology {

   // @Bean
    public Topology createTopology() {
        StreamsBuilder builder = new StreamsBuilder();

        var stream = builder.stream(
                TopicNames.SOURCE_TOPIC,
                Consumed.with(Serdes.String(), Serdes.String()));

        stream.to(TopicNames.SINK_TOPIC, Produced.with(Serdes.String(), Serdes.String()));

        return builder.build();
    }
}
