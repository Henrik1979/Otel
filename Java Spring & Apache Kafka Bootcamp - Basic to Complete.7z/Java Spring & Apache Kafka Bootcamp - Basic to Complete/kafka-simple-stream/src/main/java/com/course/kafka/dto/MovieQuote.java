package com.course.kafka.dto;

public record MovieQuote(String quote){

}