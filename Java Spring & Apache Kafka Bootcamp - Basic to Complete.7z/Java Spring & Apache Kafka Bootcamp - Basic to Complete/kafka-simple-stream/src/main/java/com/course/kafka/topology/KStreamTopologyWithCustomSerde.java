package com.course.kafka.topology;

import com.course.TopicNames;
import com.course.kafka.dto.MovieQuote;
import com.course.kafka.utils.KafkaSerdesUtils;
import com.google.gson.Gson;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class KStreamTopologyWithCustomSerde {

    private final Gson gson = new Gson();

    @Bean
    public Topology createTopology() {
        StreamsBuilder builder = new StreamsBuilder();
        var stream = builder.stream(
                TopicNames.SOURCE_TOPIC,
                Consumed.with(Serdes.String(), KafkaSerdesUtils.getSerdes(MovieQuote.class, gson)));
                stream.to(TopicNames.SINK_TOPIC, Produced.with(Serdes.String(), KafkaSerdesUtils.getSerdes(MovieQuote.class, gson)));

        return builder.build();

    }
}
