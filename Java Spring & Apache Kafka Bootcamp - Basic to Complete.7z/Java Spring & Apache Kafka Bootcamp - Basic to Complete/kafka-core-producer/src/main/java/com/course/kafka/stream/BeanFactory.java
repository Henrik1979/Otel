package com.course.kafka.stream;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Configuration
public class BeanFactory {

    @Bean
    public org.apache.kafka.clients.producer.KafkaProducer<String, String> customKafkaProducerFactory()
    {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:19092");
        props.put("linger.ms", 1);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        return new KafkaProducer<>(props);
    }
}
