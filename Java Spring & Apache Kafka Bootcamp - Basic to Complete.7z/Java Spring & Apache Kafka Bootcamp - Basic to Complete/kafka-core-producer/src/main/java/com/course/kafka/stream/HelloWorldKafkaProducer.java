package com.course.kafka.stream;

import com.course.TopicNames;
import lombok.NonNull;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HelloWorldKafkaProducer {
    private final KafkaProducer<String, String> kafkaProducer;

    public HelloWorldKafkaProducer(@Autowired @NonNull final KafkaProducer<String, String> kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    public void send(@NonNull final String message) {
        kafkaProducer.send(new ProducerRecord<>(
                TopicNames.SOURCE_TOPIC,
                "key",
                message));
    }
}