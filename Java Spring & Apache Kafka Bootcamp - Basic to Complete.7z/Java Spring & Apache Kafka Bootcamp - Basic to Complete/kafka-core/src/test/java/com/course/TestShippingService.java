package com.course;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TestShippingService {
    @Test
    void incorrectWeight() {
        ShippingService shippingService = new ShippingService();
        assertThrows(IllegalStateException.class, () -> shippingService.calculateShippingFee(-1));
    }

    @Test
    void topicname() {
        assertThat(TopicNames.SOURCE_TOPIC).isNotBlank();
        assertDoesNotThrow(TopicNames::new);
    }


    @Test
    void firstRangeWeight() {
        ShippingService shippingService = new ShippingService();
        assertThat(shippingService.calculateShippingFee(1)).isEqualTo(5);
    }
}
