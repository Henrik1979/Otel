package com.course;

public class TopicNames {
    public static final String SINK_TOPIC = "sink";
    public static final String MOVIE_QUOTE_SINK_TOPIC = "movie_quote_sink";
    public static final String MOVIE_QUOTE_PROTOBUF_SINK_TOPIC = "movie_quote_protobuf_sink";
    public static final String SOURCE_TOPIC = "source";
}
