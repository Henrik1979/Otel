package com.course.kafka.stream;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.concurrent.ThreadLocalRandom;

@SpringBootApplication
public class KafkaCoreProducerApplication implements CommandLineRunner {
    private final HelloWorldKafkaProducer producer;

    public KafkaCoreProducerApplication(@Autowired @NonNull final HelloWorldKafkaProducer producer) {
        this.producer = producer;
    }

    public static void main(String[] args) {
        SpringApplication.run(KafkaCoreProducerApplication.class, args);
    }

    @Override
    public void run(String... args) {
        producer.send(String.valueOf(ThreadLocalRandom.current().nextInt()));
    }
}
