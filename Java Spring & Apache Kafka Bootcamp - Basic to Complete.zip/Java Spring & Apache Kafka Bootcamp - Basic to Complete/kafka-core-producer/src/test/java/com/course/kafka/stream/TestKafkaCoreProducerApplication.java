package com.course.kafka.stream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestKafkaCoreProducerApplication {

	@Test
	void contextLoads() {
	}



}
