package com.course.kafka.stream;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNull;

class DummyTest
{
    @Test
    void dummy(){
        assertNull(null);
        assertThat(1).isNotEqualTo(2);
    }

}
