package com.course.kafka.telemetry;

import com.course.kafka.App;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.LongHistogram;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static io.opentelemetry.api.common.AttributeKey.stringKey;

@Component
public class Meter {
    private final io.opentelemetry.api.metrics.Meter meter;
    private LongHistogram histogram;

    public Meter(final @Autowired OpenTelemetry opentelemetry) {
        meter = opentelemetry.getMeter(App.class.getSimpleName());
    }

    @PostConstruct
    public void configure()
    {
        histogram = meter.histogramBuilder("kafka.processing.time")
                .ofLongs() // Required to get a LongHistogram, default is DoubleHistogram
                .setDescription("The time used in processing from mainframe to current processing step")
               // .setExplicitBucketBoundariesAdvice(Arrays.asList(1L, 2L, 3L, 4L, 5L, 6L, 7L))
                .setUnit("millis")
                .build();
    }

    public void recordProcessingTime(long millis, String processingStep){
        histogram.record(7, Attributes.of(stringKey("processing.step"), processingStep));
    }
}
