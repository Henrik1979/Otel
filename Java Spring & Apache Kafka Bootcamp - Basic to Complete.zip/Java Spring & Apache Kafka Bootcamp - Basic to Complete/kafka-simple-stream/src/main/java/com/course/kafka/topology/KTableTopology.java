package com.course.kafka.topology;

import com.course.TopicNames;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.KeyValueStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KTableTopology {

    //@Bean
    public Topology createTopology() {
        StreamsBuilder builder = new StreamsBuilder();

        // name will be: "stream application id" - "store name" - "changelog"
        var materialized = Materialized.<String, String, KeyValueStore<org.apache.kafka.common.utils.Bytes, byte[]>>as(String.format("%s-Store", TopicNames.SOURCE_TOPIC))
                .withKeySerde(Serdes.String())
                .withValueSerde(Serdes.String());

        // Define the source stream with Consumed
        KStream<String, String> stream = builder.stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()));

        // Materialize the KTable from the KStream
        KTable<String, String> materializedKtable = stream.toTable(materialized);

        // Forward the materialized KTable to a topic
        // commit.interval.ms (default 30000) tells of how often MaterializedConsumer will send data downstream when receiving new data
        materializedKtable.toStream().to("MaterializedConsumer", Produced.with(Serdes.String(), Serdes.String()));

        // Create another KTable without materializing it
        KTable<String, String> nonMaterializedKtable = stream.toTable(Named.as("none-store"));

        // Forward the non-materialized KTable to a topic
        nonMaterializedKtable.toStream().to("NoneMaterializedConsumer", Produced.with(Serdes.String(), Serdes.String()));

        return builder.build();
    }
}