package com.course.kafka.stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaCoreConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaCoreConsumerApplication.class, args);
	}
}
