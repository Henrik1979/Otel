package com.course;

public class TopicNames {
    public static final String SINK_TOPIC = "sink";
    public static final String SOURCE_TOPIC = "HelloWorldTopic";
}
