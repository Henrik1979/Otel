package com.course.kafka.stream;

import com.course.TopicNames;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BasicTopology {

//    @Bean
//    public Topology createTopology(){
//        StreamsBuilder builder = new StreamsBuilder();
//
//        // Define your source topic
//        KStream<String, String> stream = builder.stream( TopicNames.SOURCE_TOPIC,
//                Consumed.with(Serdes.String(), Serdes.String()));
//
//        // Perform some operations
//        KStream<String, String> transformedStream = stream.mapValues(value -> value.toUpperCase());
//
//        // Define your sink topic
//        transformedStream.to(TopicNames.SINK_TOPIC,
//                Produced.with(Serdes.String(), Serdes.String()));
//
//        return builder.build();
//    }

    @Bean
    void buildPipeline(@Autowired StreamsBuilder builder) {

        builder.stream(TopicNames.SOURCE_TOPIC, Consumed.with(Serdes.String(), Serdes.String()))
                .to(TopicNames.SINK_TOPIC,
                        Produced.with(Serdes.String(), Serdes.String()));
    }
}
