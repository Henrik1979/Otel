package com.course.kafka.stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.EnableKafkaStreams;

@EnableKafkaStreams
@SpringBootApplication
@ConfigurationPropertiesScan
@EnableKafka
public class KafkaCoreStreamApplication {
    public static void main(String[] args) {
        SpringApplication.run(KafkaCoreStreamApplication.class, args);
    }
}